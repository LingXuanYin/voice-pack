// SPDX-License-Identifier: Apache-2.0
//
// Cohub 适配器的运行环境：把所需能力对到 Cohub 上的模型（对照表是 capability-map.json），组装出注入的运行环境。
//
//   const env = createCohubEnvironment({ client, spaceId, fetch });
//   await env.capabilities['voice-cloning']({ text: '……', ref_audio: { bytes, mimeType: 'audio/wav' } });
//
// 这一层在浏览器和 Node 里都能跑，不碰 node:*、process、Buffer，也不读环境变量：
//   - Cohub 客户端由外面注入：app 里用 app 自己的客户端，agent 环境里用 cohub-cli 自带的客户端。
//     「在 agent 环境里找到 cohub-cli 的客户端」是 Node 专有的，在 ./cli/client.mjs 里，由 ./adapter.mjs（命令行上的 --adapter cohub）接上。
//   - 凭据、Space 由调用方给；网络读取（下载生成出来的音频）用注入的 fetch，没给就抛 fetch_missing。
//
// 提供的所需能力（调用签名都在 vocab/capability-signatures.md，这里只标注实现了哪几项）：
//   @capability text-to-speech      对照表里 text-to-speech 对的模型。不收参考音频；instructions 当作没传（Cohub 上没有 style-instruction）
//   @capability voice-cloning       对照表里 voice-cloning 对的模型。默认只用一段参考，ref_audio 给数组才是融合
//   @capability voice-design        对照表里 voice-design 对的模型。描述（voice_prompt）放在建任务的 meta.voice_prompt 里，试听文本放在文字块里，不带参考。
//                                   发出去之前先查三件事（都在碰 Cohub 之前，一次调用也没有，不花钱）：两个参数都是非空字符串；两个参数的长度没有超过对照表里写的上限
//                                   （试听文本 maxTextChars，描述 maxPromptChars，数 UTF-16 的单位数，表里没写就不拦）；两个参数里没有增补平面的字（对照表写了 noSupplementaryChars 才拦）。
//                                   量法和为什么（描述超了上限被 Cohub 当成「服务暂时出错」，带一个增补平面的字就让服务白等一分钟超时）见 requireWithin、requireSupported 上的说明
//   @capability audio-text-to-text  对照表里 audio-text-to-text 对的模型。音频按 base64 放进 image 内容块（见下）
//   @capability text-generation     对照表里 text-generation 对的模型。一次补全，文字提示进 user 消息，不带音频；失败的报法同 audio-text-to-text
//   @capability automatic-speech-recognition  对照表里这一项对的是一个服务（Cohub 云端转写），不是模型：走网关的 WebSocket（asr-gateway.mjs）。
//                                   网关只吃 16 kHz、单声道、16 位的 PCM：音频已经是这个格式（WAV）就直接送，别的格式用环境的 ffmpeg 运行时先转；
//                                   调用方给了 accessToken 才有这项能力（令牌怎么拿见 README.md「转写的令牌」）。返回只有 text 和 model（服务名）：网关不报语言，也没有时间戳。
//                                   能收的语言是对照表这一项的 languages（现在是 zh、en）：调用方带了别的语言，在连网关之前就报 capability_input_invalid（规则的正本是 vocab/capability-signatures.md）；
//                                   app 用导出的 recognizesLanguage 决定一段录音走云端还是走本机，适配器自己查的是同一个函数
// 对照表里没有模型的能力（没列，或标了 unavailable，例如 speaker-verification）不提供：用到它的功能会抛 capability_missing 并点名。
// 模型名只来自对照表，不写在代码里。调用方可以用 options.capabilities 补上别的实现（例如 app 的本机说话人验证），同名的盖过这里的。
//
// 三件只有 Cohub 才有的做法（前两件 2026-10-14 实测，第三件 2026-10-15）：
//   1. 参考音频一律先上传，再用上传后拿到的网址生成，不把包外的网址直接交给生成接口。
//      用 public.cohub.live 上的网址当参考，服务商取不到（TLS 握手超时，HTTP 502）；
//      用 client.publicAssets.uploadGenerationInput 传上去的（主机是另一个）可以用，一次克隆约 54 秒。
//      同一段音频（字节和 MIME 类型都一样）在一个环境里只上传一次：缓存的是「上传这件事」，同时发起的几次调用共用同一次上传；
//      上传失败不进缓存。缓存跟着环境走，换一个环境就是另一次运行。
//   2. 让模型听音频：音频按 base64 放进 image 内容块，media_type 填音频的类型。
//      Cohub 的 LLM 接口会把 audio 内容块直接丢掉，模型就听不到；这个用法 Cohub 的文档里没有，所以只在这一层里用。
//      哪天失效了，还原度盲听的收音校验会报错（模型转写不出已知文本）。
//   3. 转写不走生成接口，走网关的 WebSocket，用使用者自己的令牌鉴权（协议见 asr-gateway.mjs 文件头）。令牌由调用方给（options.accessToken），
//      这里不读环境变量；它只出现在发给网关的 auth 消息里，任何报错、details 里都没有它。每一次转写开一个新连接，所以可以同时转写几段。
//      转写不自动重试：不清楚网关怎么计费，重来可能重复计费；暂时出错的标 details.transient，要不要重来由调用方定。
//
// 失败（VoicePackError；code 小写下划线，details 里放什么在抛出处写明）：
//   cohub_client_invalid     注入的客户端缺要用的方法。details.missing 是缺的方法名
//   capability_map_invalid   对照表不是 { capabilities: {…} }
//   cohub_space_missing      调用能力时没有 Space（生成和调用要记在使用者自己的 Space 上）。details.capability
//   capability_input_invalid 调用的参数不对（缺文字、parts 形状不对……）。details.capability、details.field；转写还有 details.problem：audio 的 undecodable、empty，
//                            language 的 unsupported（云端转写认不了这种语言，details.language 是调用方带来的标签；写法见 vocab/capability-signatures.md）；
//                            voice-design 的 text 和 voice_prompt 还有 details.problem：too_long（超过对照表里的上限，details.length 是它的长度，details.max 是上限）、
//                            unsupported_characters（带增补平面的字，details.characters 是其中不同的字，最多 10 个，按第一次出现的先后）；缺参数、是空白没有 problem
//   cohub_unauthorized       Cohub 回了 HTTP 401（转写：网关回 asr.error 的 UNAUTHORIZED，或 system.auth.ok 以外的 system.auth* 消息，也算 401）。
//                            details.status、capability、action。本机上一次 401 就会清掉 Cohub 的登录态，
//                            所以这之后这个环境不再向 Cohub 发任何请求，后续调用直接抛同一个 code（details.halted 为 true）；调用方应当停下来
//   cohub_request_failed     别的失败：上游报错（details.status 是 HTTP 状态）、网络错误（没有 status）、任务本身失败（上游服务商报错，
//                            没有 status，原话在 message 里）。details.capability、action（generate 建任务、wait 等结果、upload、download、
//                            completion、transcribe 转写，转写失败还带 details.stage：connect、auth、start、audio、finish，
//                            和网关在 payload.code 里给的 details.gatewayCode）、
//                            message（上游原话，截断过）；建好任务以后的失败带 details.taskRunId；重试过的带 details.attempts；
//                            details.transient 总有：true 表示服务暂时出错（没有 HTTP 状态的网络错误，或 HTTP 408、425、429、5xx，
//                            和下面「重试」里判断要不要重试的是同一套，规则在 failure.mjs，调用方也用它；任务本身失败、Cohub 的原话里写着服务商回的 HTTP 状态时，
//                            按那个状态用同一套判断，见 failure.mjs 的 taskFailure（例外：声音设计的描述超过上限，Cohub 也写 HTTP 502，可原样再发还是一样，标 false，见 promptTooLong）；
//                            转写：连不上、连接出错或断开、哪一步等不到回应），稍后重新来过也许就成；
//                            false 是别的 4xx、原话里认不出服务商状态的任务失败、网关明确报的错（asr.error、system.error）等，重来也没用。
//                            还原度（lib/fidelity.mjs）据此把一条盲听记成「没听成」而不是整份作废，约定见 vocab/capability-signatures.md。
//                            底层错误在 cause 里。要不要重新来过由调用方定，见下面「重试」
//   cohub_result_invalid     Cohub 回了，但内容不是该有的样子：生成结果里没有音频、没有任务号、上传没返回网址、
//                            回答里没有文字、stopReason 是 error、下载回来的音频认不出类型。details.capability 和说明问题的字段
//   provider_blocked         听音频（audio-text-to-text）的回答被模型的服务商用内容过滤拦下了：回答的位置上是服务商自己的一句说明，不是模型的回答
//                            （认法和实测见 failure.mjs 的 blockedByProvider；文字生成不认）。details.capability、model、provider（服务商的名字，小写）、
//                            reply（回答里从服务商那句说明开始的前 300 个字符，超过的加省略号）。不带 transient：同一段录音再问还是被拦，不是「服务暂时出错」，补全也不重试；
//                            不是 401，这个环境之后照常能用。还原度和打标签（lib/fidelity.mjs、lib/segment-tags.mjs）只认这个 code，
//                            把那一条记成「作废」，不记成「没听成」，约定见 vocab/capability-signatures.md
//   cohub_token_unavailable  要用令牌（转写）时拿不到：accessToken 是函数而它抛了错，或给出来的不是非空字符串。details.capability、reason
//                            （threw 或 empty）；函数抛的错在 cause 里。不是 401，不拦后面的调用
//   websocket_missing        转写要 WebSocket，调用方没给（options.WebSocket），运行时也没有全局的。details.capability
//   另外 audio_clip_invalid（音频参数不是 { bytes, mimeType }）、fetch_missing、runtime_missing（转写要把别的格式转成 16 kHz 单声道，环境没有 ffmpeg）
//   来自核心层。转写的音频转不了（ffmpeg 说不是音频、转出来是空的）报 capability_input_invalid，details.problem 是 undecodable 或 empty。
//
// 重试：只重试不花钱、可以重复做的几步，别的一概不自动重试。
//   - 会重试：等生成结果（轮询任务，是只读的 GET）、上传参考音频、下载生成结果。只在「瞬时的传输错误」时重试：没有 HTTP 状态的网络错误
//     （连不上、超时、连接被重置），或 HTTP 408、425、429、5xx；最多再试 options.retries 次（默认 3），间隔 options.retryDelayMs（默认 2 秒）
//     起每次翻倍。等结果重试时接着等**同一个任务**，不重新建任务，而且总共等的时间不超过 options.timeoutMs。
//     为什么要有：2026-10-14 在本机实测，一次克隆在轮询中途遇到一次 10 秒的连接超时，任务其实还在跑；不重试就丢了一个已经计费的任务。
//   - 不重试：建任务（可能已经计费，重建会重复计费）、给模型的补全（同理）；任务本身失败（上游服务商报错，plain Error：再等同一个任务还是失败，
//     服务商的状态只用来标 transient）、等到超时、别的 4xx、401（单独处理，见上）。这些由调用方定：例如上游 5xx 隔几分钟重新调用一次，最多三次。
//     算不算「暂时出错」的规则在 failure.mjs（isTransient、taskFailure），调用方判断要不要重来用同一份，不另写一套（app 配音时，建好的任务失败了就为这一句换一个新任务；
//     建任务那一步失败不重试，和这里一致）。
//
// 模块约定见 protocol/README.md：只用平台自带的 API，浏览器和 Node 都能跑；适配器只依赖核心层。
import { toBase64, toHex } from '../../protocol/lib/bytes.mjs';
import { VoicePackError, isVoicePackError } from '../../protocol/lib/errors.mjs';
import { assertAudioClip } from '../../protocol/lib/audio-clip.mjs';
import { requireFetch, requireRuntime } from '../../protocol/lib/env.mjs';
import { pcmOfRecognitionWav, recognize } from './asr-gateway.mjs';
import { isTransient, taskFailure, blockedByProvider } from './failure.mjs';
import { flagOf, limitOf, supplementaryOf } from './limits.mjs';
import defaultCapabilityMap from './capability-map.json' with { type: 'json' };

/**
 * 回答被模型的服务商拦下时，错误的说明：给人看的一句话，报告和界面直接用它。
 * 「多半因为台词是现成的文章」是推测，不是查实的原因：实测被拦下的都是新闻朗读（票 34），服务商只给了一句笼统的说明，所以说「多半」。
 */
const BLOCKED_MESSAGE = '模型的服务商拦下了这一段的回答（多半因为台词是现成的文章），这一段不算数';

/** 上传参考音频时给文件起名用的后缀。文件名决定不了什么，MIME 类型才是准的，所以认不得的类型用 .bin。 */
const EXTENSION_OF = {
  'audio/wav': 'wav',
  'audio/x-wav': 'wav',
  'audio/wave': 'wav',
  'audio/mpeg': 'mp3',
  'audio/mp3': 'mp3',
  'audio/mp4': 'm4a',
  'audio/x-m4a': 'm4a',
  'audio/aac': 'aac',
  'audio/ogg': 'ogg',
  'audio/webm': 'webm',
  'audio/flac': 'flac',
  'audio/x-flac': 'flac',
};
/** 下载回来的音频，响应头里没有音频类型时，按网址后缀认。 */
const MIME_OF = { wav: 'audio/wav', mp3: 'audio/mpeg', m4a: 'audio/mp4', aac: 'audio/aac', ogg: 'audio/ogg', opus: 'audio/ogg', webm: 'audio/webm', flac: 'audio/flac' };

const mediaType = (mimeType) => mimeType.split(';')[0].trim().toLowerCase();
const filenameFor = (clip) => `reference.${EXTENSION_OF[mediaType(clip.mimeType)] ?? 'bin'}`;
// Cohub 的报错可能很长：只留一段，别把整个响应体写进日志
const short = (value, limit = 300) => {
  const text = String(value);
  return text.length > limit ? `${text.slice(0, limit)}…` : text;
};

/** 从对照表里取一项能力的模型 id；没列、标了不可用、没有模型 id，都当作环境没有这项能力。 */
function modelOf(map, capability) {
  const model = map.capabilities[capability]?.model;
  return typeof model === 'string' && model !== '' ? model : null;
}

/** 从对照表里取一项由服务（不是模型）提供的能力：{ service, url, languages? }；没列、没有 service 或 url，都当作环境没有这项能力。languages 是服务认的语言（主语言的小写数组），没写就是不限制。 */
function serviceOf(map, capability) {
  const entry = map.capabilities[capability];
  if (typeof entry?.service !== 'string' || entry.service === '' || typeof entry.url !== 'string' || entry.url === '') return null;
  const languages = Array.isArray(entry.languages) ? entry.languages.filter((tag) => typeof tag === 'string' && tag.trim() !== '').map((tag) => tag.trim().toLowerCase()) : null;
  return { service: entry.service, url: entry.url, languages };
}

/** 语言标签的主语言，小写：zh-CN、zh_TW、ZH 都是 zh。不是非空字符串就是 null。 */
const primaryLanguage = (language) => (typeof language === 'string' && language.trim() !== '' ? language.trim().split(/[-_]/)[0].toLowerCase() : null);

/**
 * 云端转写收不收一个带着这种 language 的调用（规则的正本在 vocab/capability-signatures.md 的 automatic-speech-recognition 一节，认哪些是对照表里这一项的 languages）。app 用它决定一段录音
 * 走云端还是走本机，适配器自己检查 language 参数用的也是它，所以两边不会不一致。`und`（未定）等于没说语言，收；不是语言标签（不是字符串、空串）不收；
 * 对照表里没写 languages，不限制，都收。
 * @param {unknown} language BCP 47 语言标签（zh、en-US、pt-BR）
 * @param {object} [capabilityMap] 默认用本目录的 capability-map.json
 * @returns {boolean}
 */
export function recognizesLanguage(language, capabilityMap = defaultCapabilityMap) {
  const primary = primaryLanguage(language);
  if (primary === null) return false;
  if (primary === 'und') return true;
  const service = serviceOf(capabilityMap, 'automatic-speech-recognition');
  return service?.languages == null || service.languages.includes(primary);
}

/** 转写要的 ffmpeg 参数：别的格式转成网关吃的 16 kHz、单声道、16 位 PCM 的 WAV。输入输出的写法和卫生同 tools/audio-decode.mjs 文件头的 @runtime ffmpeg。 */
const RECOGNITION_FFMPEG_ARGS = Object.freeze([
  '-hide_banner', '-nostdin', '-v', 'error',
  '-protocol_whitelist', 'file',
  '-i', '{input}',
  '-map', '0:a:0',
  '-ac', '1', '-ar', '16000',
  '-f', 'wav', '-acodec', 'pcm_s16le',
  '{output}',
]);

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** 响应头里的音频类型；响应头没有音频类型（没有，或是 application/octet-stream 之类）就按网址的后缀认；还认不出就是空串。 */
function audioTypeOf(response, url) {
  const header = mediaType(String(response.headers?.get?.('content-type') ?? ''));
  if (header.startsWith('audio/')) return header;
  let pathname;
  try {
    pathname = new URL(String(url)).pathname;
  } catch {
    pathname = String(url).split('?')[0];
  }
  const extension = pathname.toLowerCase().split('.').pop();
  return MIME_OF[extension] ?? '';
}

/**
 * 组装 Cohub 环境的运行环境。
 * @param {object} options
 * @param {object} options.client Cohub 客户端（app 的，或 agent 环境里 cohub-cli 的）。必须有 generations.create、generations.wait；
 *   用到参考音频才需要 publicAssets.uploadGenerationInput，用到 audio-text-to-text 才需要 space(id).completion
 * @param {string} [options.spaceId] 生成和调用记在哪个 Space 上。不给也能组装，调用能力时才报 cohub_space_missing
 * @param {function} [options.fetch] 网络读取，下载生成出来的音频用。形同标准 fetch(input, init)；不给，合成类能力在建任务之前就抛 fetch_missing（不白花钱）
 * @param {object} [options.capabilityMap] 所需能力到模型的对照表，默认用本目录的 capability-map.json
 * @param {Record<string, function>} [options.capabilities] 调用方补充的能力，同名的盖过这里提供的
 * @param {Record<string, function>} [options.runtimes] 命令行工具，原样放进环境
 * @param {number} [options.timeoutMs] 等一次生成的上限（含重试时接着等的时间），默认 10 分钟
 * @param {number} [options.intervalMs] 轮询生成结果的间隔，默认 3 秒
 * @param {number} [options.retries] 等结果、上传、下载遇到瞬时的传输错误时，最多再试几次（建任务和补全从不自动重试），默认 3，设 0 就不重试
 * @param {number} [options.retryDelayMs] 第一次重试前停多久，之后每次翻倍，默认 2000 毫秒
 * @param {number} [options.maxCompletionTokens] audio-text-to-text 一次回答的长度上限，默认 4000
 * @param {string|(() => string|Promise<string>)} [options.accessToken] 使用者的令牌，转写鉴权用；给函数就每次转写时现取（令牌会过期、会刷新）。不给就没有 automatic-speech-recognition
 * @param {function} [options.WebSocket] WebSocket 的构造函数，转写用；不给用运行时自带的 globalThis.WebSocket（浏览器、Bun、Node 22 以上都有）
 * @param {object} [options.asr] 转写的细节：frameMs（每帧多少毫秒，默认 200）、frameGapMs（帧间停多久，默认 17）、connectTimeoutMs（连接、等令牌确认、等开始，每一步最多等多久，默认 15 秒）、
 *   idleTimeoutMs（发完以后网关多久没有任何回应算超时，默认 30 秒）
 * @returns {{ capabilities: Record<string, function>, runtimes: object, fetch?: function }} 注入的运行环境
 * @throws {VoicePackError} cohub_client_invalid、capability_map_invalid
 */
export function createCohubEnvironment({
  client,
  spaceId = null,
  fetch: fetchImpl,
  capabilityMap = defaultCapabilityMap,
  capabilities = {},
  runtimes = {},
  timeoutMs = 10 * 60_000,
  intervalMs = 3000,
  retries = 3,
  retryDelayMs = 2000,
  maxCompletionTokens = 4000,
  accessToken,
  WebSocket: webSocketOption,
  asr = {},
} = {}) {
  const missing = [];
  if (typeof client?.generations?.create !== 'function') missing.push('generations.create');
  if (typeof client?.generations?.wait !== 'function') missing.push('generations.wait');
  if (missing.length > 0) throw new VoicePackError('cohub_client_invalid', `Cohub 客户端缺少要用的方法：${missing.join('、')}`, { details: { missing } });
  if (capabilityMap === null || typeof capabilityMap !== 'object' || capabilityMap.capabilities === null || typeof capabilityMap.capabilities !== 'object') {
    throw new VoicePackError('capability_map_invalid', '所需能力对照表必须是 { capabilities: {…} } 对象', { details: { field: 'capabilities' } });
  }
  const models = {
    'text-to-speech': modelOf(capabilityMap, 'text-to-speech'),
    'voice-cloning': modelOf(capabilityMap, 'voice-cloning'),
    'voice-design': modelOf(capabilityMap, 'voice-design'),
    'audio-text-to-text': modelOf(capabilityMap, 'audio-text-to-text'),
    'text-generation': modelOf(capabilityMap, 'text-generation'),
  };
  const asrService = serviceOf(capabilityMap, 'automatic-speech-recognition');
  // 声音设计的限制（对照表里写了才拦，没写不替它编一个；写坏了当没写，规则在 limits.mjs，app 数字数、去字用的是同一份）
  const designTextMax = limitOf(capabilityMap, 'voice-design', 'maxTextChars');
  const designPromptMax = limitOf(capabilityMap, 'voice-design', 'maxPromptChars');
  const designNoSupplementary = flagOf(capabilityMap, 'voice-design', 'noSupplementaryChars');

  const env = { capabilities: {}, runtimes };
  if (typeof fetchImpl === 'function') env.fetch = fetchImpl;

  // ---- 失败怎么报
  let halted = null; // 收到过 401：不再向 Cohub 发任何请求
  const haltedError = (capability, action) =>
    new VoicePackError('cohub_unauthorized', `这个环境此前收到过 Cohub 的 HTTP 401，不再向 Cohub 发请求（本机上一次 401 就会清掉 Cohub 登录态）：先停下来，确认登录态再继续`, {
      details: { status: 401, capability, action, halted: true, firstMessage: halted.message },
    });
  const refuseIfHalted = (capability, action) => {
    if (halted !== null) throw haltedError(capability, action);
  };
  /**
   * 调一次 Cohub。401 单独报并拦住后续调用（authenticated 为 false 的不算：下载不带凭据）；别的失败带上 HTTP 状态，
   * 并用 transient 标出它是不是「服务暂时出错」（isTransient：同一套判断也决定哪几步重试），调用方据此决定要不要稍后重新来过。
   * extra：失败时要补进 details 的东西（任务号、重试了几次），失败的那一刻才取值。
   */
  async function platform(capability, action, run, { authenticated = true, extra = () => ({}) } = {}) {
    try {
      return await run();
    } catch (cause) {
      if (isVoicePackError(cause)) throw cause;
      const status = Number.isInteger(cause?.status) ? cause.status : undefined;
      const details = { capability, action, ...(status === undefined ? {} : { status }), ...(typeof cause?.gatewayCode === 'string' ? { gatewayCode: cause.gatewayCode } : {}), message: short(cause?.message ?? cause), ...extra() };
      const description = `${short(cause?.message ?? cause)}${status === undefined ? '' : `（HTTP ${status}）`}`;
      if (authenticated && status === 401) {
        const error = new VoicePackError('cohub_unauthorized', `Cohub 拒绝了这次请求的凭据（${capability}，${action}）：${description}。这个环境之后不再向 Cohub 发请求；本机上一次 401 就会清掉 Cohub 登录态，先停下来确认登录态`, { details, cause });
        halted = error;
        throw error;
      }
      throw new VoicePackError('cohub_request_failed', `调用 Cohub 失败（${capability}，${action}）：${description}`, { details: { ...details, transient: isTransient(cause) }, cause });
    }
  }
  /**
   * 重复做一件不花钱、可以重复做的事，直到成功；只在瞬时的传输错误时重试，最多再试 retries 次，间隔每次翻倍；过了 deadline 就不再试。
   * progress.attempts 记下一共试了几次，失败的报错里要用。
   */
  async function repeat(run, progress, deadline = Infinity) {
    for (;;) {
      progress.attempts += 1;
      try {
        return await run();
      } catch (error) {
        if (progress.attempts > retries || !isTransient(error) || Date.now() >= deadline) throw error;
        await sleep(retryDelayMs * 2 ** (progress.attempts - 1));
      }
    }
  }
  const resultInvalid = (capability, message, details = {}) => new VoicePackError('cohub_result_invalid', message, { details: { capability, ...details } });
  const inputInvalid = (capability, field, message) => new VoicePackError('capability_input_invalid', message, { details: { capability, field } });

  const requireSpace = (capability) => {
    if (typeof spaceId !== 'string' || spaceId === '') {
      throw new VoicePackError('cohub_space_missing', `调用 ${capability} 要有 Space：生成和调用都记在使用者自己的 Space 上，创建环境时给 spaceId`, { details: { capability } });
    }
    return spaceId;
  };
  const requireText = (capability, text) => {
    if (typeof text !== 'string' || text.trim() === '') throw inputInvalid(capability, 'text', `${capability} 的 text 必须是非空字符串（要说的话）`);
  };
  const requireVoicePrompt = (capability, voicePrompt) => {
    if (typeof voicePrompt !== 'string' || voicePrompt.trim() === '') throw inputInvalid(capability, 'voice_prompt', `${capability} 的 voice_prompt 必须是非空字符串（用文字描述想要的声音）`);
  };
  /**
   * 对照表写了这项能力带增补平面的字就处理不了（noSupplementaryChars）：有就在碰 Cohub 之前报 capability_input_invalid，details.problem 是 unsupported_characters，
   * details.characters 是有哪几个字（不同的，按第一次出现的先后，最多十个）。声音设计带一个这样的字就让服务超时，约 1 分钟后回 HTTP 502（2026-10-18 对着真 Cohub 量，票 45 第 3 条）：
   * 白等一分钟，而且这个 502 还被标成暂时出错、被人重试。适配器不替调用方把它们去掉：调用方给的话，改不改由调用方定。规则的正本是 vocab/capability-signatures.md 的 voice-design 一节。
   */
  const requireSupported = (capability, field, value, noSupplementary) => {
    if (!noSupplementary) return;
    const found = supplementaryOf(value);
    if (found.length === 0) return;
    const characters = [...new Set(found)].slice(0, 10);
    throw new VoicePackError('capability_input_invalid', `${capability} 的 ${field} 里有 Cohub 的声音设计处理不了的字：${characters.join(' ')}（码点在 U+FFFF 以上的字，表情符号、生僻汉字都是；带一个就让服务超时，约 1 分钟后回 HTTP 502），没有调用；去掉它们再调`, {
      details: { capability, field, problem: 'unsupported_characters', characters },
    });
  };
  /**
   * 一个字符串参数超过对照表里写的上限：在碰 Cohub 之前报 capability_input_invalid，details.problem 是 too_long，details.length 是它有多少个字符，details.max 是上限。
   * 数法是 UTF-16 的单位数（String.length），两个参数都是（2026-10-18、19 对着真 Cohub 量的）：199 个汉字加一个表情符号，试听文本算 201，被拒；
   * 499 个汉字加一个表情符号，描述算 501，被上游 DashScope 拒（HTTP 400「voice_prompt should not be longer than 500 characters」）。
   * Cohub 自己在 DashScope 前面也数一遍描述，它数的是码点（「voice_prompt must be at most 500 characters, got 550」：400 个汉字加 150 个表情符号，550 是码点数），比单位数宽，
   * 所以起作用的是上游那一道，按单位数。
   * 这是调用方和环境之间的事，不是服务出了问题：不标 transient。规则的正本是 vocab/capability-signatures.md 的 voice-design 一节。
   */
  const requireWithin = (capability, field, value, max, limitName) => {
    if (max !== undefined && value.length > max) {
      throw new VoicePackError('capability_input_invalid', `${capability} 的 ${field} 太长了：${value.length} 个字符，Cohub 一次最多收 ${max} 个（对照表里 ${capability} 的 ${limitName}，数法是 UTF-16 的单位数，和服务商一致），没有调用`, {
        details: { capability, field, problem: 'too_long', length: value.length, max },
      });
    }
  };

  // ---- 参考音频：先上传，同一段只传一次
  const uploads = new Map(); // 指纹 -> 上传这件事（Promise<公开网址>）
  const identities = new WeakMap(); // 没有 crypto.subtle（例如非安全上下文里的浏览器）时退而按字节对象认
  let identityCount = 0;
  const fingerprint = async (clip) => {
    const subtle = globalThis.crypto?.subtle;
    if (subtle === undefined) {
      if (!identities.has(clip.bytes)) identities.set(clip.bytes, ++identityCount);
      return `object:${identities.get(clip.bytes)}:${clip.mimeType}`;
    }
    return `sha256:${toHex(new Uint8Array(await subtle.digest('SHA-256', clip.bytes)))}:${clip.mimeType}`;
  };
  const uploadOnce = (clip) => {
    const progress = { attempts: 0 };
    return platform(
      'voice-cloning',
      'upload',
      async () => {
        if (typeof client.publicAssets?.uploadGenerationInput !== 'function') {
          throw new VoicePackError('cohub_client_invalid', '用参考音频要有客户端的 publicAssets.uploadGenerationInput（把本地音频传成公开网址）', { details: { missing: ['publicAssets.uploadGenerationInput'] } });
        }
        const uploaded = await repeat(
          () => client.publicAssets.uploadGenerationInput({ file: new Blob([clip.bytes], { type: clip.mimeType }), mimeType: clip.mimeType, filename: filenameFor(clip) }),
          progress,
        );
        const url = uploaded?.publicUrl;
        if (typeof url !== 'string' || url === '') throw resultInvalid('voice-cloning', '上传参考音频后没有拿到公开网址（publicUrl），不用别的网址顶替', { action: 'upload' });
        return url;
      },
      { extra: () => (progress.attempts > 1 ? { attempts: progress.attempts } : {}) },
    );
  };
  const uploadReference = async (clip) => {
    const key = await fingerprint(clip);
    let pending = uploads.get(key);
    if (pending === undefined) {
      pending = uploadOnce(clip);
      uploads.set(key, pending);
      pending.catch(() => {
        if (uploads.get(key) === pending) uploads.delete(key); // 失败的上传不进缓存
      });
    }
    return pending;
  };

  // ---- 一次生成：建任务、等结果、把音频下回来
  const download = (capability, url) => {
    const progress = { attempts: 0 };
    return platform(
      capability,
      'download',
      async () => {
        const { response, bytes } = await repeat(async () => {
          const response = await requireFetch(env)(url);
          if (response?.ok === false) throw Object.assign(new Error(`下载生成结果失败：HTTP ${response.status}`), { status: response.status });
          return { response, bytes: new Uint8Array(await response.arrayBuffer()) };
        }, progress);
        const mimeType = audioTypeOf(response, url);
        if (mimeType === '') throw resultInvalid(capability, `下载回来的音频认不出类型：响应头里没有音频类型，网址的后缀也看不出`, { url: short(url) });
        return { bytes, mimeType };
      },
      { authenticated: false, extra: () => (progress.attempts > 1 ? { attempts: progress.attempts } : {}) },
    );
  };
  const generate = async (capability, { text, model, references = [], meta }) => {
    const content = [{ type: 'text', text }];
    for (const url of references) content.push({ type: 'audio', source: { type: 'url', url }, ...(references.length > 1 ? { meta: { weight: 1 } } : {}) });
    // 建任务：不自动重试（可能已经计费，重建会重复计费）。meta 是整个任务的参数（声音设计的描述放在 meta.voice_prompt），不是某块参考音频的
    const taskRunId = await platform(capability, 'generate', async () => {
      const created = await client.generations.create({ spaceId: requireSpace(capability), model, content, ...(meta === undefined ? {} : { meta }) });
      if (typeof created?.taskRunId !== 'string' || created.taskRunId === '') throw resultInvalid(capability, 'Cohub 创建生成任务后没有返回任务号（taskRunId）', { model });
      return created.taskRunId;
    });
    // 等结果：只读的轮询，遇到瞬时的传输错误就接着等同一个任务；总共等的时间不超过 timeoutMs。任务本身失败了不再等，按 taskFailure 标
    const deadline = Date.now() + timeoutMs;
    const progress = { attempts: 0 };
    const result = await platform(
      capability,
      'wait',
      async () => {
        try {
          return await repeat(() => client.generations.wait(taskRunId, { timeoutMs: Math.max(1, deadline - Date.now()), intervalMs }), progress, deadline);
        } catch (error) {
          throw taskFailure(error) ?? error;
        }
      },
      { extra: () => ({ taskRunId, ...(progress.attempts > 1 ? { attempts: progress.attempts } : {}) }) },
    );
    const blocks = Array.isArray(result?.output) ? result.output : [];
    const url = blocks.find((block) => block?.type === 'audio')?.source?.url;
    if (typeof url !== 'string' || url === '') throw resultInvalid(capability, `Cohub 的生成结果里没有音频（模型 ${model}）`, { model, taskRunId, blocks: blocks.map((block) => String(block?.type)) });
    return { ...(await download(capability, url)), model };
  };

  // ---- 一次补全：audio-text-to-text 和 text-generation 共用，只是 user 消息里放的内容块不同
  // 建补全不自动重试（可能已经计费，重来会重复计费）；失败的报法同上面的 platform。
  // 听音频的补全拿到的回答如果是服务商的拦截说明，报 provider_blocked（认法见 failure.mjs 的 blockedByProvider）；这一步在 stopReason 和「没有文字」的检查之前：
  // 拦截说明本身就是最清楚的原因。文字生成不认它：它的调用方自己解析自己要的格式，回答就是回答。
  const complete = async (capability, content) => {
    const space = requireSpace(capability);
    const model = models[capability];
    const response = await platform(capability, 'completion', async () => {
      if (typeof client.space !== 'function') throw new VoicePackError('cohub_client_invalid', `用 ${capability} 要有客户端的 space(id).completion`, { details: { missing: ['space'] } });
      return client.space(space).completion({ model, messages: [{ role: 'user', content }], temperature: 0, maxTokens: maxCompletionTokens, thinkingLevel: 'low' });
    });
    const message = response?.message;
    const text = (Array.isArray(message?.content) ? message.content : [])
      .filter((block) => block?.type === 'text' && typeof block.text === 'string')
      .map((block) => block.text)
      .join('');
    const blocked = capability === 'audio-text-to-text' ? blockedByProvider(text) : null;
    if (blocked !== null) throw new VoicePackError('provider_blocked', BLOCKED_MESSAGE, { details: { capability, model, provider: blocked.provider, reply: short(blocked.notice) } });
    if (message?.stopReason === 'error' || message?.stopReason === 'aborted') {
      throw resultInvalid(capability, `Cohub 的回答没有正常结束（stopReason：${message.stopReason}）`, { model, stopReason: message.stopReason });
    }
    if (text.trim() === '') throw resultInvalid(capability, 'Cohub 的回答里没有文字', { model });
    return { text, model };
  };

  // ---- 提供的能力
  if (models['text-to-speech'] !== null) {
    env.capabilities['text-to-speech'] = async ({ text } = {}) => {
      refuseIfHalted('text-to-speech', 'generate');
      requireText('text-to-speech', text);
      requireSpace('text-to-speech');
      requireFetch(env);
      return generate('text-to-speech', { text, model: models['text-to-speech'] });
    };
  }

  if (models['voice-cloning'] !== null) {
    env.capabilities['voice-cloning'] = async ({ text, ref_audio: refAudio } = {}) => {
      refuseIfHalted('voice-cloning', 'upload');
      requireText('voice-cloning', text);
      const fusion = Array.isArray(refAudio);
      const clips = fusion ? refAudio : [refAudio];
      if (clips.length === 0) throw inputInvalid('voice-cloning', 'ref_audio', 'voice-cloning 至少要一段参考音频（ref_audio）');
      clips.forEach((clip, index) => assertAudioClip(clip, fusion ? `ref_audio[${index}]` : 'ref_audio'));
      requireSpace('voice-cloning');
      requireFetch(env);
      const references = [];
      for (const clip of clips) references.push(await uploadReference(clip)); // 按顺序，一段一段传：顺序要和权重、生成请求里的先后一致
      return generate('voice-cloning', { text, model: models['voice-cloning'], references });
    };
  }

  if (models['voice-design'] !== null) {
    env.capabilities['voice-design'] = async ({ text, voice_prompt: voicePrompt } = {}) => {
      refuseIfHalted('voice-design', 'generate');
      requireText('voice-design', text);
      requireVoicePrompt('voice-design', voicePrompt);
      requireSupported('voice-design', 'text', text, designNoSupplementary);
      requireWithin('voice-design', 'text', text, designTextMax, 'maxTextChars');
      requireSupported('voice-design', 'voice_prompt', voicePrompt, designNoSupplementary);
      requireWithin('voice-design', 'voice_prompt', voicePrompt, designPromptMax, 'maxPromptChars');
      requireSpace('voice-design');
      requireFetch(env);
      return generate('voice-design', { text, model: models['voice-design'], meta: { voice_prompt: voicePrompt } });
    };
  }

  if (models['audio-text-to-text'] !== null) {
    env.capabilities['audio-text-to-text'] = async ({ parts } = {}) => {
      const capability = 'audio-text-to-text';
      refuseIfHalted(capability, 'completion');
      if (!Array.isArray(parts) || parts.length === 0) throw inputInvalid(capability, 'parts', `${capability} 的 parts 必须是非空数组：文字和音频按顺序交替`);
      const content = parts.map((part, index) => {
        if (typeof part?.text === 'string') return { type: 'text', text: part.text };
        if (part?.audio !== undefined) {
          assertAudioClip(part.audio, `parts[${index}].audio`);
          return { type: 'image', source: { type: 'base64', media_type: part.audio.mimeType, data: toBase64(part.audio.bytes) } };
        }
        throw inputInvalid(capability, `parts[${index}]`, `parts[${index}] 必须是 { text: 字符串 } 或 { audio: { bytes, mimeType } }`);
      });
      return complete(capability, content);
    };
  }

  if (models['text-generation'] !== null) {
    env.capabilities['text-generation'] = async ({ prompt } = {}) => {
      const capability = 'text-generation';
      refuseIfHalted(capability, 'completion');
      if (typeof prompt !== 'string' || prompt.trim() === '') throw inputInvalid(capability, 'prompt', `${capability} 的 prompt 必须是非空字符串（给模型的文字提示）`);
      return complete(capability, [{ type: 'text', text: prompt }]);
    };
  }

  // ---- 转写：走网关的 WebSocket，不是生成任务。令牌由调用方给，每次转写时现取
  if (asrService !== null && (typeof accessToken === 'function' || (typeof accessToken === 'string' && accessToken.trim() !== ''))) {
    const capability = 'automatic-speech-recognition';
    const tokenNow = async () => {
      let token;
      try {
        token = typeof accessToken === 'function' ? await accessToken() : accessToken;
      } catch (cause) {
        throw new VoicePackError('cohub_token_unavailable', `拿不到 Cohub 的令牌（${capability}）：${short(cause?.message ?? cause)}`, { details: { capability, reason: 'threw' }, cause });
      }
      if (typeof token !== 'string' || token.trim() === '') {
        throw new VoicePackError('cohub_token_unavailable', `拿不到 Cohub 的令牌（${capability}）：给出来的不是非空字符串`, { details: { capability, reason: 'empty' } });
      }
      return token.trim();
    };
    const invalidAudio = (problem, message, cause) => new VoicePackError('capability_input_invalid', message, { details: { capability, field: 'audio', problem }, ...(cause === undefined ? {} : { cause }) });
    /** 送给网关的 PCM：已经是 16 kHz、单声道、16 位的 WAV 就直接取，别的格式用环境的 ffmpeg 转。 */
    const recognitionPcm = async (clip) => {
      const direct = pcmOfRecognitionWav(clip.bytes);
      if ('pcm' in direct) return direct.pcm;
      if (direct.problem === 'empty') throw invalidAudio('empty', `${capability} 的音频是空的：WAV 里没有采样`);
      const ffmpeg = requireRuntime({ capabilities: {}, runtimes }, 'ffmpeg');
      let converted;
      try {
        converted = await ffmpeg([...RECOGNITION_FFMPEG_ARGS], clip.bytes);
      } catch (cause) {
        throw invalidAudio('undecodable', `${capability} 的音频转不成 16 kHz 单声道（ffmpeg 说：${short(cause?.message ?? cause)}）`, cause);
      }
      const result = converted instanceof Uint8Array ? pcmOfRecognitionWav(converted) : { problem: 'format', found: 'ffmpeg 返回的不是字节' };
      if ('pcm' in result) return result.pcm;
      throw invalidAudio(result.problem === 'empty' ? 'empty' : 'undecodable', `${capability} 的音频转出来不能用：${result.found}`);
    };
    env.capabilities[capability] = async ({ audio, language } = {}) => {
      refuseIfHalted(capability, 'transcribe');
      assertAudioClip(audio, 'audio');
      // 录音的语言调用方知道就带上；认不了的语言报错，不去转（转出来是编的文字）。这一步在连网关、取令牌、转格式之前：什么都没花，规则见 vocab/capability-signatures.md
      if (language !== undefined && language !== null) {
        if (primaryLanguage(language) === null) throw inputInvalid(capability, 'language', `${capability} 的 language 必须是语言标签的字符串（BCP 47，例如 es、zh-CN）`);
        if (!recognizesLanguage(language, capabilityMap)) {
          throw new VoicePackError('capability_input_invalid', `Cohub 云端转写认不了这种语言（${language.trim()}），没有转写；它只认 ${asrService.languages.join('、')}`, { details: { capability, field: 'language', problem: 'unsupported', language: language.trim(), supported: [...asrService.languages] } });
        }
      }
      const WebSocketImpl = webSocketOption ?? globalThis.WebSocket;
      if (typeof WebSocketImpl !== 'function') {
        throw new VoicePackError('websocket_missing', `调用 ${capability} 要有 WebSocket：创建环境时给 options.WebSocket，或者用自带 WebSocket 的运行时（浏览器、Bun、Node 22 以上）`, { details: { capability } });
      }
      const pcm = await recognitionPcm(audio);
      const token = await tokenNow();
      const progress = { stage: 'connect' };
      const { text } = await platform(
        capability,
        'transcribe',
        () => recognize({ ...asr, WebSocket: WebSocketImpl, url: asrService.url, token, pcm, onStage: (stage) => { progress.stage = stage; } }),
        { extra: () => ({ stage: progress.stage }) },
      );
      return { text, model: asrService.service };
    };
  }

  Object.assign(env.capabilities, capabilities);
  return env;
}
