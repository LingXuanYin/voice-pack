# voice-pack 基础部分 / base part

这是音色包的基础部分（`voice-pack/`），版本 3.0.0-beta.18：通用的流程、协议核心、词表、环境适配层和官方小工具，不含任何具体的声音。
The base part of voice packs (`voice-pack/`), version 3.0.0-beta.18: shared flows, the protocol core, vocabularies, environment adapters and official tools. It contains no voice.

`voice-pack.voicepack.zip` 是一个普通的 zip。解压后把 `voice-pack/` 放进 `.agents/skills/`，再复制一份到 `.claude/skills/`；入口是 `SKILL.md`。
It is a plain zip. Unzip it, put the directory into `.agents/skills/` and copy it into `.claude/skills/`; the entry point is `SKILL.md`.
