// SPDX-License-Identifier: Apache-2.0
//
// Cohub 的失败里哪些算「服务暂时出错」（稍后重新来过也许就成）：一条规则，Cohub 适配器（env.mjs）和调用方都用它，不各写一份。
// 重不重试、等多久、重试时重建任务还是接着等同一个任务，由调用方定（env.mjs 文件头「重试」一节写了适配器自己的选择）；这里只回答「算不算暂时出错」。
// 例如 app 配音时，一句话的生成任务暂时失败了，就为这一句重新建任务（vs3/src/lib/generation-retry.ts），判断用的就是这里的规则。
// 注意：算「暂时出错」只说明稍后重来也许就成，不是说可以重建任务。建任务那一步失败时，Cohub 那头可能已经建好了任务、已经计费，重建会重复收费：
// 适配器不重试建任务，app 配音也只在手里有任务号时才重试。
//
//   isTransientStatus(status)  HTTP 状态：408、425、429、5xx 算暂时出错。请求自己的状态和任务失败时服务商回的状态都用这一条
//   isTransient(error)         一个失败算不算暂时出错（规则见函数上的说明）
//   taskFailure(error)         任务在 Cohub 那头失败了：从 SDK 抛的那段文字里读出服务商回的状态，返回带 transient 的错误；认不出返回 null
//
// 怎么接（env.mjs 的 generate 就是这样接的）：
//   - 建任务失败（HTTP 错误、网络错误）：isTransient(error)
//   - 等结果时失败：isTransient(taskFailure(error) ?? error)。任务本身失败时 SDK（@neta-art/cohub 的 generations.wait）只抛一段文字，
//     服务商的状态在文字里，taskFailure 把它读出来；读不出来的任务失败（例如只有 fetch failed）照旧不算暂时出错
//
// 模块约定见 protocol/README.md：只用平台自带的 API，浏览器和 Node 都能跑；适配器只依赖核心层。
import { isVoicePackError } from '../../protocol/lib/errors.mjs';

/** HTTP 状态里哪些算服务暂时出错：408、425、429、5xx。请求自己的状态和任务失败时服务商回的状态都用这一条。 */
export const isTransientStatus = (status) => status === 408 || status === 425 || status === 429 || status >= 500;
/** 没有 HTTP 状态的网络错误带的错误码（Node 的 undici 和系统调用）。 */
const NETWORK_CODES = new Set(['UND_ERR_CONNECT_TIMEOUT', 'UND_ERR_HEADERS_TIMEOUT', 'UND_ERR_BODY_TIMEOUT', 'UND_ERR_SOCKET', 'ECONNRESET', 'ECONNREFUSED', 'ECONNABORTED', 'ETIMEDOUT', 'ENOTFOUND', 'EAI_AGAIN', 'EPIPE']);
/** 瞬时的传输错误：没有 HTTP 状态的网络错误，或 isTransientStatus 的状态。别的（4xx、超时、我们自己的 VoicePackError）都不是。带 transient 布尔值的错误（转写网关的、taskFailure 的）以它为准。 */
export function isTransient(error) {
  if (isVoicePackError(error)) return false;
  if (typeof error?.transient === 'boolean') return error.transient;
  if (Number.isInteger(error?.status)) return isTransientStatus(error.status);
  for (let cause = error, depth = 0; cause !== null && typeof cause === 'object' && depth < 5; cause = cause.cause, depth++) {
    if (NETWORK_CODES.has(cause.code)) return true;
  }
  // 浏览器和没带错误码的实现：fetch 连不上时抛的是 TypeError
  return error instanceof TypeError && /fetch failed|failed to fetch|networkerror|network request failed|load failed/i.test(String(error.message));
}
/**
 * 等结果时任务在 Cohub 那头失败了。SDK（@neta-art/cohub 的 generations.wait）这时只抛一段文字：任务的 errorMessage，换行，一行任务号。
 * Cohub 写服务商的失败是「Generation provider is temporarily unavailable — HTTP 502 — details …」「Generation provider request failed — HTTP 400 — details …」
 * （2026-10-16 读 Space 里 18 条失败的生成任务：15 条 502、504，2 条 400，1 条只有 fetch failed）。认得出这种写法，就按服务商回的状态用 isTransientStatus 标：
 * 返回一个带 transient 的错误，原来的错误在 cause 里；不带 status（那是服务商的状态，不是这次请求的，401 也不拦后面的调用）。认不出返回 null，照旧不算暂时出错。
 * 任务已经失败了，再等同一个任务也是同样的结果：这里只给最后报错用，不进 repeat 的重试判断。
 */
const PROVIDER_FAILURE_RE = /^Generation provider\b[^\n]*?\bHTTP (\d{3})\b/;
export function taskFailure(error) {
  if (isVoicePackError(error) || typeof error?.message !== 'string') return null;
  const found = PROVIDER_FAILURE_RE.exec(error.message);
  if (found === null) return null;
  return Object.assign(new Error(error.message, { cause: error }), { transient: isTransientStatus(Number(found[1])) });
}
