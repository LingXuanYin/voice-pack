// SPDX-License-Identifier: Apache-2.0
//
// 声音设计对输入的限制，怎么读、怎么数。Cohub 适配器（env.mjs）在调用之前查，app 在页面上数（vs3/src/lib/design-prompt.ts）、在发出去之前去掉（vs3/src/lib/tts.ts），
// 用的是这一份，不各写一套。限制本身（数字、标记）写在对照表 capability-map.json 里，这里只有读它的办法和数法；
// 每个限制是怎么量出来的，写在对照表的 $comment 和 reference/product-contract.md，这里不重述。
//
//   limitOf(map, capability, field)       对照表里这项能力的字数上限（maxTextChars、maxPromptChars）。只有正整数才算，别的（没写、0、负数、字符串、小数）
//                                         一概当没写，返回 undefined：写坏的表不会把所有文字都拦下
//   flagOf(map, capability, field)        对照表里这项能力的标记（noSupplementaryChars）。只认 true，别的都是 false
//   supplementaryOf(value)                字符串里码点大于 U+FFFF 的字（增补平面：表情符号、CJK 扩展 B 以后的生僻汉字、数学字母……），按出现的先后，重复的也列。
//                                         基本平面里长得像的（❤️ U+2764 加 U+FE0F、✨、CJK 扩展 A、兼容汉字、U+FFFF）不算
//   withoutSupplementary(value)           去掉它们：{ text, removed }。别的字一个不动，removed 是去掉的不同的字，按第一次出现的先后（给页面说「去掉了什么」）
//
// 数字符的单位是 UTF-16 的单位数（String.length），和服务商数的一样，所以这里不提供「数字符」的函数：调用方直接用 .length。
// 不是字符串的输入不抛错：supplementaryOf、withoutSupplementary 当它是空串。
//
// 模块约定见 protocol/README.md：只用平台自带的 API，浏览器和 Node 都能跑。
const isPlainObject = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
const rowOf = (map, capability) => {
  const row = isPlainObject(map?.capabilities) ? map.capabilities[capability] : undefined;
  return isPlainObject(row) ? row : undefined;
};

/** @returns {number | undefined} */
export function limitOf(map, capability, field) {
  const value = rowOf(map, capability)?.[field];
  return Number.isInteger(value) && value > 0 ? value : undefined;
}

/** @returns {boolean} */
export const flagOf = (map, capability, field) => rowOf(map, capability)?.[field] === true;

const isSupplementary = (character) => character.codePointAt(0) > 0xffff;

/** @returns {string[]} */
export const supplementaryOf = (value) => (typeof value === 'string' ? [...value].filter(isSupplementary) : []);

/** @returns {{ text: string, removed: string[] }} */
export function withoutSupplementary(value) {
  const text = typeof value === 'string' ? value : '';
  const found = supplementaryOf(text);
  if (found.length === 0) return { text, removed: [] };
  return { text: [...text].filter((character) => !isSupplementary(character)).join(''), removed: [...new Set(found)] };
}
