---
name: cohub-voice-studio
description: "音色包（voice pack）的基础部分，同时是 Cohub Voice Studio 的使用说明。Base part of the voice pack format and the Cohub Voice Studio guide: clone, design and blend voices, generate speech, audiobooks, dubbing, batches and transcripts, and read, check and complete voice packs. Flows are written by required capability (text-to-speech, voice-cloning, voice-design, ...) and an environment adapter maps them to concrete models. Use when working with voice packs, voice cloning, voice design or blending, script markup, or the Voice Studio app, its community library, or its HTTP, OpenAI-compatible or MCP APIs. 声音克隆、声音设计、音色融合，配音、有声书、批量生成、转写，音色包的读写、检查和补全。"
license: Apache-2.0
compatibility: "需要带 Web Crypto、Compression Streams（deflate-raw）和 fetch 的运行时：当前的浏览器，或 Node.js（在 24.14 上测过）。用到模型的功能，需要运行环境提供对应的所需能力，见 adapters/。"
---

# 音色包的基础部分

音色包由两个部分组成：**角色部分**（一个声音的参考集和配音指引）和**基础部分**（本目录）。基础部分放与具体角色无关的东西：造声音和合成语音的通用流程、协议核心（格式说明，读写和检查音色包的程序）、各类词表、环境适配层和官方小工具。目录总览见 `README.md`。

流程按**所需能力**来写，不点名模型。模型只从**适配器**接进来：一个适配器把所需能力对到一个运行环境里的具体模型，所有适配器合起来叫**环境适配层**（`adapters/`）；模型名只出现在适配器自己的目录 `adapters/<名字>/` 里。

## 0. 红线

1. **费用归使用者自己。** 生成、大语言模型和转写都跑在使用者自己的账户和空间上，由使用者授权；不用站长或作者的额度，不保存使用者的令牌。Cohub 上怎么授权，见 `adapters/cohub/`。
2. **模型名不写进基础部分，也不凭记忆写。** 流程里只写所需能力。某项能力在当前运行环境用哪个模型、有什么限制，查接进来的适配器的对照表；模型的实时参数用运行环境自己的方式查（Cohub 上是 `cohub models show <模型 id>`）。

## 1. 所需能力

- **能力词表**在 `vocab/capabilities.json`，带版本号，分三层：有通用名字的照用 Hugging Face 的任务名（`text-to-speech`、`automatic-speech-recognition`、`audio-text-to-text`、`text-generation` 等）；没有通用名字的用业内趋同的叫法（`voice-cloning`、`voice-design`、`audio-source-separation` 等）；参数名用 `ref_audio`、`ref_text`、`instructions`。流程和包里写的所需能力，只能从这份词表里取。
- **运行环境缺某项能力时**，只有用到它的功能报错，并说明缺的是哪一项，其他功能照常。程序里怎么取能力、怎么报这个错，见 `protocol/README.md` 的「运行环境」。
- **每种运行环境一个适配器**，在 `adapters/<名字>/`。官方的有两个：`cohub`（所需能力到 Cohub 模型的对照表、产品契约、参考文档，入口 `adapters/cohub/README.md`）和 `process`（把能力调用转给你自己的程序，入口 `adapters/process/README.md`）；适配器怎么写、怎么接，约定只写在 `adapters/README.md`。
- 要用模型才能做的处理（分离、水印、说话人相似度、转写）不在这里实现，作为所需能力向运行环境要；运行环境没有的，就报不可用。

## 2. 造声音的三条路

| 流程 | 所需能力 | 输入 | 输出 |
|---|---|---|---|
| 克隆 | `voice-cloning`（参数 `ref_audio`、`ref_text`）；逐字文本可用 `automatic-speech-recognition` 转写 | 一段干净的参考（5–20 秒，不带伴奏）和它的逐字文本 | 一个声音 |
| 设计 | `voice-design` | 按设计词表选的属性，写成一段自然语言描述 | 候选声音；满意的锁定成参考，之后走克隆 |
| 融合 | `voice-cloning`，传多段参考 | 2 段以上参考，各带权重 | 一个融合的声音 |

**克隆**

1. 参考音频：上传、录音或从声音库里挑，裁成一段干净的。
2. 需要时清理：去伴奏用 `audio-source-separation`；响度在本机归一到 −20 LUFS。
3. 逐字文本：用 `automatic-speech-recognition` 转写，或手写，再核对一遍。
4. 试听：用这段参考合成一句。
5. 写上名字、语言、性别、标签和简介，保存。

**设计**

1. 从设计词表（`vocab/design.json`）挑属性：性别、年龄、音高、风格、英语口音、中文方言；可以再加音色、节奏、情绪的标签，也可以从预设角色起步。
2. 把属性写成自然语言描述。可以手写，也可以让 `text-generation` 按一段话来写。
3. 用 `voice-design` 合成试听。描述和试听文本的最小长度这类限制，由运行环境的产品契约给出；两项的上限（试听文本、描述各最多多少个字符）和描述处理不了哪些字，由运行环境适配器的对照表给出（Cohub 适配器的 `maxTextChars`、`maxPromptChars`、`noSupplementaryChars`），超了服务商会让这次合成失败，或者干脆超时。
4. 满意的候选锁定成参考。之后用它就是克隆。

**融合**：权重是和始终为 1 的份额，调一个，其余按比例重新分配。最多能融合几段，由运行环境的产品契约（`maxRefs`）给出。

**怎么选能力**：有描述而没有参考，用 `voice-design`；参考多于一段，用 `voice-cloning` 做融合；其余按调用者的要求，没要求时有参考用 `voice-cloning`，没有参考用 `text-to-speech`。

## 3. 合成一段话

1. 应用读音词表：把容易读错的词换成期望的读法。
2. 分句：长文本按运行环境的单段上限切开；有台本标记时按标记切。
3. 解析台本标记（见下一节）。
4. 逐段生成，多段可以并发。**每段生成任务的 id 要记下来**：重新加载后接着用同一批任务，不重复付费。
5. 本地拼接：去静音、淡入淡出、插入停顿、变速。
6. 需要时加水印（`audio-watermarking`）。
7. 汇总费用。

用一个音色包给台本配音时，每一句还要挑参考，读包里的读音词表和配音指引，见第 6 节「用音色包配音和变声」。
## 4. 台本标记、场景和设计词表

这几份词表是 JSON，放在 `vocab/`，app、服务端和程序读的是同一份。

**台本标记**（名单见 `vocab/markup.json`）：

| 写法 | 作用 |
|---|---|
| `# 标题` | 一章的开头 |
| `[pause 0.6s]` | 停顿，单位是 `s` 或 `ms`；不写时长就用默认值 |
| `[voice:<声音>]` | 从这里起换一个声音 |
| `[slow]…[/slow]`、`[fast]…[/fast]` | 放慢、加快；可以嵌套；不写结束标记，就到这一行结束 |
| `[emphasis]…[/emphasis]` | 强调 |
| `[spell]…[/spell]` | 逐字拼读 |
| `（耳语）`、`*笑*` | 舞台提示，转成语气提示（耳语、笑、叹气、生气等）；括号里不是整个都是提示的内容怎么处理，见第 6 节 |

精确的语法和解析程序，见 `tools/` 里的台本标记解析。

**场景**（`vocab/scenes.json`）：台本润色按场景选规则，由 `text-generation` 执行。每个场景有 id 和中英文名，例如 `news`（新闻播报）、`narration`（有声书 / 长文旁白）、`dubbing`（本地化配音）。

**设计词表**（`vocab/design.json`）：设计声音时用的属性（分类和可选值）、音色 / 节奏 / 情绪的标签，以及 8 个预设角色。

## 5. 命令行

在本目录运行 `node cli.mjs help` 列出当前可用的命令，`node cli.mjs <命令> --help` 看用法。只有协议核心时用 `node protocol/cli.mjs`。命令行默认给命令一个只有网络读取、没有任何所需能力的运行环境；要用模型的命令，用 `--adapter` 把适配器接进来（见第 6 节和 `adapters/README.md`）。命令的写法、退出码和错误的报告方式，见 `protocol/README.md` 的「命令行」。放进环境、配音、变声三个命令，写在下一节；做包（`node cli.mjs make-pack`）写在第 7 节「做音色包」。

## 6. 用音色包配音和变声

拿到一个音色包（角色部分的目录，里面有 `manifest.json`、`SKILL.md`、`reference/`），先放进环境，再用它的声音给台本配音，或者把一段音频换成它的声音。三个命令都在本目录的 `cli.mjs` 里，都不点名模型，只要运行环境有对应的所需能力。

**放进环境**：`node cli.mjs install <包目录或分享文件>`。先做和 `check` 一样的检查（清单对得上文件、互相校验，还有验签：基础部分和协议核心要有官方签名），通过了才写；放进项目的 `.agents/skills/<包 ID>/`（Codex、Gemini CLI、Cursor、OpenCode、Cohub 读这里），再复制一份到 `.claude/skills/<包 ID>/`（Claude Code 读这里）。已有同名目录就拒绝，不覆盖。`--project <目录>` 指定项目，默认是当前目录。检查不过（包括签名不对），一个文件都不写，报告点名哪里不对；把它告诉使用者，不要自己想办法绕过去。

**配音**：`node cli.mjs dub <包目录> <台本文件> --out <输出目录>`。台本是带台本标记的文本（上一节），或者 `.json` 数组 `[{ "text": "…", "labels": { "emotion": "angry" }, "instructions": "…" }]`；`-` 是标准输入。先加 `--dry-run` 看规划，不合成，不花钱。

| 选项 | 作用 |
|---|---|
| `--dry-run` | 只规划：每一句说什么、挑哪段参考、为什么、读音词表换了什么、缺什么运行时 |
| `--language`、`--emotion`、`--style`、`--energy` | 调用方给的标签，用在每一句上，是最优先的一层 |
| `--instructions <文字>` | 代替包里的配音指引 |
| `--only 2,5` | 只做这几句（序号从 1 起）；重做失败的句子用它 |
| `--max-chars`、`--concurrency` | 一次最多合成多少字（超过的按句子切开）、并发数 |
| `--adapter <名字或模块文件>`、`--adapter-option <键=值>` | 模型从适配器接进来：官方的给名字，自己的给模块文件；可以给多个，后给的盖过先给的；`--adapter-option` 给前一个适配器的参数。见本节末 |
| `--cohub`、`--space <id>` | `--adapter cohub` 的简写（Cohub 适配器，Space 用 `--space`）；适配器给了费用说明时，开始之前在标准错误里说明要生成几次，记在使用者自己的账户上 |
| `--json` | 标准输出是一份 JSON |

输出目录里，每一句一个音频文件（`<序号>-<参考段>.<扩展名>`），加一份报告 `dub.json`。命令不把各句拼成一个文件：停顿、语速、该不该和前一句连着，都如实记在报告的 `units[i]`（`pauseBeforeMs`、`pauseAfterMs`、`speed`、`join`）里，拼接的人按它处理。退出码：0 全做完；1 有句子失败，或出错停下来了；2 用法错误。

**一句话是怎么变成合成的**：

1. 台本里的 `[voice:名字]` 必须是这个包（名字或包 ID）；别的名字报 `voice_unknown`，一个包只有一个声音。
2. 舞台提示（`（耳语）`、`*笑*`）变成这一句的情绪、风格、停顿和语速，从要说的话里拿掉。写法和近义词见 `vocab/cues.json`。括号里词表认不出的内容（例如 `（画外音）`），配音时也拿掉、不念，报告里记着；在配音以外的地方（例如 app 读普通正文），括号里的内容要整个都是词表里的提示才拿掉，其余（例如 `（笑话比赛）`）当正文念，不当舞台提示。规则的正本是 `lib/line-hints.mjs` 的文件头。
3. **挑参考**（`lib/reference-pick.mjs`）：从参考集里挑语言、情绪、风格最对得上的一段。「怎么说」的标签按这个顺序取，前面有了就不再往后看：调用方给的，台本里的提示，环境有 `text-generation` 时它的判断，都没有就用默认参考段。语言先比，再比情绪、风格。默认一句只用一段参考，不融合；留出录音从不当参考。挑的理由写在 `units[i].pick` 里（`rule`、`matched`、`missed`）：`missed` 不空，说明台词要的这一项，参考集里没有哪一段有（例如生气的台词，参考集里没有生气的参考）。
4. **读音词表**：包根目录的 `lexicon.pls`（W3C Pronunciation Lexicon，PLS）。只换要说的话里的词，不碰台本标记。读法是音素的做不到，报在 `lexicon.unapplied`。
5. **配音指引**：包的 `SKILL.md` 最后一节。你先读它，写台本时照着做（语气、节奏、口头禅）。运行环境有 `style-instruction` 时，命令再把它连同这一句的说明，通过参数 `instructions` 传给模型；没有就不传，报告里说明。
6. **增强件**：包里服务 `voice-cloning` 的增强件，递给能力。环境认识对应的模型就用上（报告 `enhancers.used`），不认识就照常生成，`enhancers.statement` 是 `enhancers_not_used`，并附上包的验证记录，让人知道当前环境下效果会差多少。
7. **脚本**：登记在 `dub` 功能名下的，合成之前改要说的话，合成之后改音频，见下。

**失败和重做**：服务暂时出错的句子记成 `failed`，别的句子照常做，退出 1，输出里给出带 `--only` 的重做命令；重做时，上一次做好的句子（话和参考段都没变、文件还在）原样沿用。别的错（401、参数不对、缺能力、缺运行时……）直接停下来，不再开始新的句子，已经做好的文件和一份写着 `stoppedBy` 的 `dub.json` 留着。401 说明授权有问题，先让使用者处理，不要重试。

**包里的脚本**：清单 `scripts` 里的 `{ entry, runtime, feature }`，`feature` 是 `dub` 或 `convert`。一个功能只跑登记在自己名下的脚本；没写 `feature` 的不会自动运行（配音指引可以教你手动用）。运行环境完全信任脚本：直接运行，不让使用者确认，不隔离。运行时按名字取：`node` 就是运行命令的 Node，`python` 找 `python3` 或 `python`，别的名字按 PATH 找。缺运行时，只有用到这个脚本的功能报 `runtime_missing`，在合成之前报；`--dry-run` 不报，只在输出里说缺什么。脚本从标准输入读一份 JSON，往标准输出写一份 JSON（什么都不写或 `{}` 是不改）：

- 输入：`{ protocol: 1, feature, hook, pack: { id, name, version }, unit: {…} }`。`hook` 是 `text`（合成之前，`unit.text` 是要说的话）或 `audio`（合成之后，`unit.audio` 是 Base64 的音频，`unit.mimeType` 是它的类型）；同一个脚本两个钩子都会被叫到，没什么要做的就什么都不输出。`convert` 功能只有 `audio` 钩子。
- 输出：`text` 钩子 `{ "text": "改写后的话" }`；`audio` 钩子 `{ "audio": "<Base64>", "mimeType": "audio/wav" }`。别的键、不是 JSON 对象的输出，一律报 `script_output_invalid`，不悄悄忽略。同一个功能有几个脚本时，按清单里的先后一个接一个运行。

**变声和唱歌**：`node cli.mjs convert <包目录> <音频文件> --out <文件>`；`--singing` 是唱歌（输入要是人声分轨，没有伴奏）。说话用 `voice-conversion`，唱歌用 `singing-voice-conversion`，缺哪一项，只有这个命令报 `capability_missing` 并点名缺的是哪一项，配音照常。参考用默认参考段，给了 `--language` 等标签就按标签挑。输出文件已经存在就拒绝，不覆盖，而且是在花钱之前就拒绝；接进来的适配器给了费用说明时，换声之前在标准错误里说明要调一次哪项能力（`--json` 时不说）。登记在 `convert` 功能名下的脚本在换声之后处理音频；增强件的用法同配音。

**各个功能要什么能力**：

| 功能 | 必须有 | 有就用 |
|---|---|---|
| 配音（`dub`） | `voice-cloning` | `style-instruction`（传配音指引）、`text-generation`（判断没有提示的句子的情绪）、增强件对应的模型 |
| 变声（`convert`） | `voice-conversion` 或 `singing-voice-conversion` | 增强件对应的模型 |

当前运行环境有哪些能力，看接进来的适配器；Cohub 的是 `adapters/cohub/README.md`，它提供 `voice-cloning` 和 `text-generation`，不提供 `style-instruction`、`voice-conversion`、`singing-voice-conversion`。要用别的模型，自己写一个适配器，用 `--adapter <模块文件>` 交给命令：适配器是一个函数，返回一个对象（能力、运行时、网络读取、费用说明等，键都可选，写法见 `adapters/README.md`「返回的形状」）；后给的盖过先给的，也盖过命令已有的同名项。约定只写在 `adapters/README.md`，每项能力的调用参数和返回值见 `vocab/capability-signatures.md`。适配器在本进程里直接运行，不隔离，和包里的脚本一样。

## 7. 做音色包

作者交来一批原声，做成一个音色包的角色部分：`node cli.mjs make-pack <素材> --output <新目录> --name <名字>`。输入、选项、报告、错误的正本在 `lib/make-pack.mjs` 的文件头，命令只管读文件、写文件。`--output` 的目录必须还不存在，不覆盖任何东西；协议核心要是封印过的（`--protocol` 指到官方发布的那份，开发树里没有）。

**素材**是已经切好的片段，每段一个音频文件加它说的话：目录里每个音频一段，同名的 `.json` 写 `{ text, labels, source, externalUrl }`，只有文本时同名的 `.txt` 也行；或者一份 `.json`：`{ "segments": [{ "audio": "audio/a.wav", "text": "…", "labels": { "emotion": "angry" } }], "notes": [{ "code": "…", "message": "…" }] }`。长录音不用先自己切，直接交：`--recording <文件|目录>`（目录里每个音频文件是一段长录音）。环境有 `audio-source-separation` 就先分离出人声（`--no-separate` 不分离，输入已经是干净的人声），环境有 `voice-activity-detection` 就用它给的说话区间切，没有就按能量切成 5–20 秒的段（`lib/long-recording.mjs` 文件头）；转写由做包这一步做，一段一次，费用在规划里。分离和 VAD 是花钱的调用，每段录音一次，调之前在标准错误里说明，`--dry-run` 不调（按能量切，只报段数）。切段留下的说明（例如「这次没做分离，输入要是干净的人声」）进报告的 `notes`；自己切的话，也可以写进素材 `.json` 的 `notes`，原样进报告。

**标签**：自己知道的写在 `labels` 里（`null` 是「明确没有」），给了的不再判断。没给的：语言来自 `--language`、转写或文字本身（拉丁字母认不出是英语还是法语，认不出又没给语言的那段用不上，`language_unknown`；转写不报语言时，要转写的拉丁字母原声会在付完转写费以后全部这样用不上，所以这种情况加 `--language`，命令在花钱之前会提醒一行）；情绪、风格让 `audio-text-to-text` 听着打；能量靠响度跟这一批的中位数比，至少 3 段量得出响度才算（照原始音频量，先量后调响度，不受下面「响度」那一步影响）。没有文本的片段，环境有 `automatic-speech-recognition` 才能转写，没有就用不上（`no_text`）。缺哪项能力，只有用到它的那一步跳过，报告里写明。

**响度**：写进包里的参考和留出录音统一到 −20 LUFS、采样峰值不超过 −1 dBFS（和上面克隆流程里的参考响度是同一个数；规则和这两个常量在 `tools/loudness-normalize.mjs`，用法在 `lib/make-pack-loudness.mjs` 的文件头）。生成时每句话挑不同的参考，参考之间响度差得多，配出来的整段就会一句响一句轻。音质检查、能量标签照原始音频量，调的只是放进包里的那份字节（存成 16 位 WAV）。加增益会让峰值超过上限的段（峰值比响度高 19 dB 以上，说话里有个特别响的瞬态），默认用限幅器压住过高的峰再加，最多压 6 dB，每段的 `loudness.limitedDb` 记着压了多少；压到 6 dB 还到不了目标（差 0.5 LU 以上）的，只加到能加的，报告的 `notes` 里写 `loudness_target_not_reached`，写明调完到了哪里、压了多少；上一版带来的段、外部资源、解不了的不动（`loudness_skipped`）。`--no-loudness` 关掉整个调响度，音频原样放进包里；`--no-limiter` 只关限幅器，回到只加增益（峰值太高的段到不了目标）。

**先看规划**：`--dry-run` 只做不花钱的几步（认格式、查重、音质检查），说明各项能力最多调几次，不做包、不调任何能力。接进来的适配器给了费用说明时（例如 `--cohub`），真做之前会在标准错误里再说明一遍，费用记在使用者自己的账户上。`--no-evaluate` 不试合成、不量还原度。

**参考集和留出录音**：规则只有一份，在 `lib/pack-material.mjs` 的文件头；留出录音从不当参考，数值是起始值，没拿真实的包校准过。音质检查用 `tools/` 里的阈值，不合格的片段不进包，报告点名原因。同样的音频字节只留一份（`duplicate_audio`）；发新版本时，上一版里的段是调过响度存的，新补的同一段录音也认得出来。

**还原度**：用做出来的包把留出录音的文本合成一遍（每条按它自己的标签挑参考），再按 `lib/fidelity.mjs` 文件头「怎么读这份报告」量；不要自己给它一个分数。量不了的一项报「量不了」，缺哪项能力就点名哪项；服务暂时出错的那一项记成「没听成」，写明条数和「可以补做」，不让整件事作废；回答被模型的服务商拦下的（能力抛 `provider_blocked`），那一条盲听、那一段的标签记成「作废」，另数有几条是被拦下的，不记成「没听成」，补做也不重做它（同一段录音再问还是被拦）；某一段录音里没有能嵌声纹的语音，那一条的说话人相似度记成「量不到」（写明是生成的还是留出的那一段），不进比例，不能补做（读法第 9 点）。要补做，做包时加 `--save-evaluation <新目录>`，之后 `node cli.mjs fidelity <新目录>/evaluation.json --redo <新目录>/fidelity-report.json`；要调几次，做包的报告里已经写明（`planRedo` 算的），适配器给了费用说明时，补做的 `fidelity` 开始之前还会在标准错误里再说一遍。补做不改包里的验证记录，要更新就发新版本。验证记录写在清单里：环境、模型、日期、比值（说话人相似度量不了时只有盲听，没有比值）。

**还缺什么素材**：报告里的 `hints`，一条一个原因，例如没有留出录音（`no_holdout`）、没有某种情绪的参考（`emotion_missing`）、某种语言只有一段（`language_single_reference`）、没有配音指引（`guidance_missing`）。补了素材，发新版本。

**配音指引和音色标签**：`--guidance <文件.md>` 写语气、节奏、口头禅、适合的场景，只写想要的效果，不写某个模型的指令语法，放进 `SKILL.md` 最后一节。`--direction <文件.json>`：`{ description, tags, scenes }`，音色标签只能从设计词表（`vocab/design.json`）里取，场景只能从 `vocab/scenes.json` 里取，中文名也认，写进清单的是规范写法；不在词表里的在花钱之前报 `make_pack_input_invalid`。`--lexicon <文件.pls>` 放读音词表；`--design-source <文件.json>` 记设计来源（`{ description, model, modelVersion, date }`），用设计出来的声音、默认音色、融合出来的声音做包时写；锁定的试听用 `--audition <文件>` 交：不分离（合成出来的本来就是干净的人声），同样切开、转写，一部分当参考、一部分当留出录音（做包照规则挑），设计来源写进清单；没给 `--design-source`，报告里提醒 `design_source_missing`。 `--sample-lines <文件.json>` 记示例台词：一份 JSON 数组，每项一句，原样写进清单的 `sampleLines`；最多 50 条，每条 1–500 个字符，不能只有空白（`text_blank`）；台词里可以带舞台提示，例如 `（耳语）`，格式只存这句字符串、不解析它。发新版本不给 `--sample-lines` 就沿用上一版的，给空数组就去掉。

**骨架的语言**：做出来的包里 `SKILL.md` 的骨架（各节的标题和说明）默认是中文；给英文作者做英文包，加 `--text-language en`（只有 `zh`、`en` 两个值，别的是用法错误，退出 2）。只管骨架：「## 配音指引」这一行所有语言都一样，`--name`、`--guidance`、`--direction` 里写的字原样放进包，不翻译；任何语言的包，读回来的指引都一样。发新版本用这一次给的语言，不看上一版是什么语言。规则的正本是 `protocol/FORMAT.md` 的「骨架的语言」。

**发新版本**：`--previous <上一版的包目录>`。包 ID 不变，版本号往上加（`--version` 明说，要比上一版大，否则 `make_pack_version_invalid`；或 `--bump patch|minor|major`，默认 minor），`--changelog` 不给就按变化生成一份。上一版的参考和留出录音保持原来的角色，新补的接在后面；`--drop` 去掉不要的段，`--default-segment` 换默认参考段。验证记录不带过来：这一版重新量，没量出来就没有。什么都没变不发（`make_pack_nothing_changed`）。包里记下做包时用的基础部分版本（`--base-version`，默认取这份基础部分自己的），不记来源包。

**完整包**：给了 `--base <基础部分目录>` 就放进 `cohub-voice-studio/`，不给就只有角色部分。资源默认放进包里，片段写了 `externalUrl` 才记成外部资源（清单里只有网址、大小、哈希）。增强件只保证格式上放得进去，做增强件要有能微调的运行环境，这里不做。

**分享文件**：做包时加 `--share-file <分享文件>`，包写出来以后再打一份 `.voicepack.zip`，里面带预览卡片（`index.html`）。卡片上「在 X 里打开」和「做一个你自己的」两个入口来自接进来的适配器（`--cohub` 给的是 Voice Studio 的），不用自己给链接；没有适配器给，卡片上就没有入口。这一步不验签，分发之前用 `check` 查一遍。

**照一个已有的包做新包（净室和查重）**：要做一个「你自己的」声音，不能把来源包的描述、指引、台词、录音搬进来。流程的正本是 `protocol/new-pack/README.md`（每个字段怎么写、谁能看什么），命令三步：

1. `node cli.mjs clean-room --output <净室输入目录> --tags <标签,…> --scenes <场景,…> [--words "<使用者自己的话>" | --words-file <文件>]`：把设计词表里的标签、场景词表里的场景、使用者自己的话（原样，不改写；话长、带换行就用文件那一种写法）和协议核心里的抽象规格、空白模板放进一个新目录。这一步不读来源包。
2. 把这个目录交给一个新开的会话或子 agent，由它照里面的 `BRIEF.md` 写描述、配音指引、示例台词（写进它的 `output/`）。已经读过来源包的 agent 自己不写：读到的会漏进新写的文字里。新会话要开在读不到来源包的地方；来源包装成了 skill，它的说明文字（里面有音色描述）会自动载入读到它的会话，那就不是净室，要告诉使用者。
3. 备素材（自己的录音，或者设计一个声音），做包时加 `--direction`、`--guidance`、`--sample-lines`（指到 `output/` 里写好的三个文件）和 `--source-pack <来源包的目录或分享文件>`：花钱的几步（切段、转写、打标签、试合成）之前，先把新包的文字（描述、指引、示例台词、设计来源）和录音同来源包比一遍。重合太多报 `duplicate_detected`，`details.findings` 写明是哪一项、量了多少、阈值多少，一分钱没花；文字改成自己的话、换掉那几段录音，再做。`--dry-run` 也查。

查重比的是「作者写的文字」和「同一段录音」：文字看最长公共子序列的 F1 和连续词组的重合；录音用音频指纹，换了响度、重新编码、重采样、截头去尾、混进更长的录音都认得出来，同一个人说的另一句话不算复用。不比说话人像不像，也不比标签、名字、转写和读音词表。抓不到改写（换个说法再写一遍）、变速、变调、倒放，所以它是最后一道关，不替代净室。比什么、阈值、依据都在 `lib/duplicate-check.mjs` 的文件头，标定的数据和脚本在 `api-server/tests/voicepack/duplicate-calibration/`。来源包只在这一步读（不验签、不联网），它的路径、名字、包 ID 不写进新包、标准输出、报告；新包用新的包 ID，清单的 `madeWith` 只记基础部分的版本。

## 8. 接自己的模型

要用自己的模型（本机的，或别家的服务），写一个适配器，用 `--adapter` 交给配音、变声、做包、量还原度这几个命令（第 6、7 节）。四步，每步一条命令；规则（工厂、返回的形状、出错、检查看什么、`--live` 会做什么）只写在 `adapters/README.md`，这里不重述。

1. **生成**：`node cli.mjs adapter new <目录> --capabilities <能力,…>`，能力名取自能力词表（`vocab/capabilities.json`）。模型是 Python 之类的程序时，加 `--kind process`：生成一个 Python 程序骨架，不用写适配器的代码。
2. **填写**：把生成的文件里每项能力「还没有实现」的那一行换成真的调用；每项能力上面的注释写着参数和返回值。
3. **检查**：`node cli.mjs adapter check <目录>` 只看结构，不调用模型；加 `--live` 会把每项能力用一段很短的输入真调一次，核对返回（会真的调用，可能花钱：调之前会说明调哪几项、各几次）。
4. **使用**：`node cli.mjs dub <包目录> <台本文件> --out <输出目录> --adapter <目录>`。

已经有写好的程序，不想生成骨架：`--adapter process --command "python my_tts.py"`。程序怎么和适配器说话，见 `adapters/process/README.md`。

## 9. 产品契约

**产品契约**是一个具体产品对外承诺的内容：用哪些模型、授权范围、计费红线、接口别名、限制、接口清单。它属于具体的适配器，不属于基础部分。Voice Studio 在 Cohub 上的产品契约：

- `adapters/cohub/product-contract.json`：机器可读。app（`vs3/`）和服务端（`api-server/vs3-api.js`）都读它，改一处，两边一起变。
- `adapters/cohub/capability-map.json`：所需能力到 Cohub 模型的对照表。
- `adapters/cohub/reference/`：给人读的说明，包括 Voice Studio 的页面、HTTP 接口、MCP、代码地图和产品流程。

在 Voice Studio 里干活（调接口、用 app、读代码）之前，先读 `adapters/cohub/README.md`。如果你拿到的是 `GET /skill.md` 返回的单文件，Voice Studio 的产品说明（`adapters/cohub/reference/voice-studio.md`）就接在本文件后面。
