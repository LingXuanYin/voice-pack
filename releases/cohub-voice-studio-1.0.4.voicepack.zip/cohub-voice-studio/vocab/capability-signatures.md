# 所需能力的调用签名

音色包不绑定模型，只向运行环境要所需能力（名字和分层见 `capabilities.json`，理由见 ADR-0003）。这份文件定下每项能力的**调用签名**：参数、返回值、报错。流程层和适配器照它实现，别各写一套。

每项能力在这里写一次就够了：用到它的模块在文件头用 `@capability <能力名>` 指过来，不再抄一遍签名（`grep -rn "@capability " .agents/skills/cohub-voice-studio`）。

各适配器把所需能力对到哪些模型，写在适配器自己的目录里（`../adapters/<名字>/`）。这里只写能力本身，不写模型；适配器怎么写、出错怎么报，见 `../adapters/README.md`。

## 通用约定

- 一项能力就是一个函数：**一个对象参数**，**`await` 它的返回值**（同步返回也行）。参数和返回值的字段名用 snake_case，和参数名 `ref_audio`、`ref_text`、`instructions` 一致。
- **音频一律用字节加 MIME 类型**传：`{ bytes: Uint8Array, mimeType: 'audio/wav' }`（`protocol/lib/audio-clip.mjs`）。不收 URL、Base64 字符串、文件路径。要 URL 的模型由适配器自己去上传，URL 不出现在库的接口上。
- 返回里 **`model` 是可选**的：环境愿意报出实际用了哪个模型就报，库会把它记进验证记录和还原度报告；不报就当不知道。`cost` 之类运行环境自己的字段不属于签名，由它自己留着。
- 能力自己抛的错原样往上传（库不吞）。库自己抛的错分哪两类、`code` 怎么起，见 `../protocol/README.md` 的「错误」一节。唯一的例外是下一条标出来的「服务暂时出错」。
- **服务暂时出错要标出来**：能力因为服务一时出错（上游 5xx、网关超时、网络错误、超时……）没做成时，抛 `VoicePackError`，在 `details.transient` 里写 `true`（有 HTTP 状态就放 `details.status`）。一次要调很多次能力的功能（目前是还原度）据此把这一条记下来、接着做别的，调用方事后再决定要不要补做，而不是整件事作废。缺能力、参数错、401、返回的形状不对这类重来也没用的不标；没标的错，库一律原样往上抛，不按 HTTP 状态去猜。适配器怎么标，见 `../adapters/README.md`「出错的约定」。库不替能力重试：会计费的调用（建任务、补全）重试可能重复计费。
- 环境缺这项能力时不用假装有：不提供这个键就行，用到它的功能会抛 `capability_missing` 并点名。

## 合成

### `text-to-speech`

用环境的默认音色把文字念出来。

```js
await env.capabilities['text-to-speech']({
  text,                  // string，必填：要说的话
  instructions,          // string，可选：怎么念（语气、节奏、情绪）。只写想要的效果，不用某个模型的指令语法
})
// -> { bytes: Uint8Array, mimeType: string, model?: string }
```

### `voice-cloning`

按参考音频合成新台词，声音像参考里的人。默认只用一段参考。

```js
await env.capabilities['voice-cloning']({
  text,                  // string，必填：要说的话
  ref_audio,             // {bytes, mimeType}，或它的数组（融合，见下）。必填
  ref_text,              // string，或和 ref_audio 一一对应的字符串数组。参考音频里说的原文，可选
  instructions,          // string，可选：怎么念
  enhancers,             // 增强件的数组，可选，见下面「增强件」
})
// -> { bytes: Uint8Array, mimeType: string, model?: string, enhancers_used?: string[] }
```

- `ref_audio` 给数组表示**融合**，只在调用方明确要融合时才用；给一段就只用那一段。怎么融合（等权还是带权重）由环境决定，包不传权重。
- `ref_text` 是参考音频的逐字文本。用不上的环境可以忽略它。
- `instructions`：环境有 `style-instruction` 才能按说明念；没有就**忽略**（别把它当成别的意思）。配音指引要不要传 `instructions`，先看环境有没有 `style-instruction`，见下面「怎么念」和 `lib/dub.mjs`。
- `enhancers`：可选，包里服务这项能力的增强件，用法见下面「增强件」。返回值里可以多一项 `enhancers_used`。

## 听

### `audio-text-to-text`

听一段或几段音频，按文字指令回答。盲听、给声音打标签都用它。

```js
await env.capabilities['audio-text-to-text']({
  parts,                 // Array<{ text: string } | { audio: {bytes, mimeType} }>，必填：按顺序交替的文字和音频
})
// -> { text: string, model?: string }
```

- `parts` 按顺序拼成一次请求：文字是给模型的说明，音频就是它要听的那几段。两段音频就按它们在 `parts` 里的先后当作 X、Y，**不另外传角色标记**（`{ audio }` 那项只放音频）。
- `text` 是模型的回答原文，库自己解析（盲听要求回答是一个 JSON 对象，见 `lib/fidelity.mjs` 的 `parseBlindAnswer`）。
- 不给温度、最大长度之类的参数：用环境自己的默认值，同一段音频答得稳一点更好。
- **服务商拦下了回答**（服务商用内容过滤把这次回答截断或换掉，回答的位置上是服务商自己的一句说明，不是模型的回答）：抛 `VoicePackError('provider_blocked', 给人看的一句话, { details: { capability: 'audio-text-to-text', provider, reply, model? } })`，`provider` 是服务商的名字（小写），`reply` 是回答里服务商那句说明的前 300 个字符。这是适配器的事：认的是服务商的原话，哪家服务商说了什么只写在适配器里（Cohub 适配器见 `../adapters/cohub/failure.mjs` 的 `blockedByProvider`），换了服务商就在那里加它的说法；不要把这句说明当成回答的 `text` 交给库，库会把它当成「不是 JSON」。不标 `transient`：同一段录音再问还是被拦，不是「服务暂时出错」，不要标成能重来。给人看的那一句话建议写成「模型的服务商拦下了这一段的回答（多半因为台词是现成的文章），这一段不算数」，报告和命令行直接用它。库（`lib/fidelity.mjs`、`lib/segment-tags.mjs`）**只认 `provider_blocked` 这个 code**：盲听那一条、打标签那一段记成「作废」（不记成「没听成」，补做也不会重做它），另外数有几条是被拦下的（`blocked`），写明是被拦下而不是「回答不是固定格式」，不进任何比例（读法第 5 点）。别的写法（能力自己起的码）库不认，照常往上抛。

### `automatic-speech-recognition`

把一段语音转写成文字。做包时给没有文本的原声补逐字文本：长录音先切段再逐段转写（`lib/long-recording.mjs`），交给做包流程的片段没有文本时它自己转写（`lib/make-pack-transcribe.mjs`）。

```js
await env.capabilities['automatic-speech-recognition']({
  audio,                 // {bytes, mimeType}，必填：要转写的那一段
})
// -> { text: string, language?: string, model?: string }
```

- `text` 是识别出来的文字，首尾空白去掉。一句也没识别出来（静音、纯音乐）是空串，**不是错误**。
- `language` 可选：环境报得出语言就报（BCP 47，例如 `en`、`zh`），报不出就不带，库当作不知道、从文字本身认。
- 一次转写一段：长录音先切段（`../tools/silence-split.mjs`），不要把几十分钟的录音整段交进来。单次最长多少，写在各适配器自己的说明里。
- 返回里**没有时间戳**：切段不靠转写的时间戳。所以长录音靠 `../tools/silence-split.mjs` 按能量切（没有 `voice-activity-detection` 的环境），切好以后逐段转写，文字就对得上每一段。
- 音频格式环境自己负责：能直接收的就收，收不了的自己转（例如只收 16 kHz、单声道、16 位的 WAV 的服务，别的格式用环境的 `ffmpeg` 运行时转，环境没有 ffmpeg 就抛 `runtime_missing`）。
- 凭据被拒（401）怎么办，见 `../adapters/README.md`「出错的约定」。
- 暂时出错（连不上、连接断开、哪一步等不到回应）按「通用约定」标 `details.transient: true`；服务明确报的错不标。库不替它重试：不清楚服务怎么计费，重来可能重复计费。

## 评测

### `speaker-verification`

判断两段语音是不是同一个人，给出说话人相似度。

```js
await env.capabilities['speaker-verification']({
  audio_a,               // {bytes, mimeType}，必填
  audio_b,               // {bytes, mimeType}，必填
})
// -> { similarity: number, model?: string }
```

- `similarity` 是有限数（越多越像）。两次调用之间要能比大小：同一次评测里必须用同一个模型（否则还原度的比值没有意义，库会抛 `evaluation_model_mismatch`）。
- 只给相似度，不给「是不是同一个人」的结论：相似度的比值和盲听的结果怎么读，见 `lib/fidelity.mjs` 文件头「怎么读这份报告」。
- **某一段录音里没有能嵌声纹的语音**（短到嵌不出、近乎静音）：抛 `VoicePackError('capability_input_invalid', 原话, { details: { capability: 'speaker-verification', field, problem: 'no_speech' } })`，`field` 是嵌不出的那一路，`'audio_a'` 或 `'audio_b'`；两段都嵌不出时报 `'audio_a'`。这是那一段录音自己的事，不是环境坏了：不标 `transient`，同一段再算还是一样。还原度（`lib/fidelity.mjs`）只认这个写法：那一条的说话人相似度记成「量不到」，写明是哪一段，不进比例，别的条照常量，整份报告照常出（读法第 9 点）。别的写法（能力自己起的码、没写明 `field`）库不认，照常往上抛。同一个 `capability_input_invalid` 加 `details.problem` 的写法，转写能力也在用（`undecodable`、`empty`）。
- 一次还原度评测要对 N 段真录音两两算（N(N-1)/2 次调用），实现可以自己按音频内容缓存嵌入、省掉重复计算。

## 处理长录音

做包流程（`lib/long-recording.mjs`）处理一段长录音时依次用到的两项能力，都是可选的：缺哪一项，只有那一步跳过，报告里写明。

### `audio-source-separation`

把混在一起的音频分成人声和伴奏等分轨。做包时先把录音里的人声分出来，再切段。

```js
await env.capabilities['audio-source-separation']({
  audio,                 // {bytes, mimeType}，必填：混在一起的录音
})
// -> { vocals: {bytes, mimeType}, accompaniment?: {bytes, mimeType}, model?: string }
```

- `vocals` 必有，是分出来的人声分轨，库只用它。`accompaniment` 和别的分轨环境愿意给就给，库不用。
- 环境没有这项能力：做包流程就跳过这一步，在报告里写明「这次没做分离，输入要是干净的人声」。
- 是花钱、耗时的调用，库不重试；失败原样往上传。

### `voice-activity-detection`

找出音频里哪些时间段有人在说话。做包时用它给长录音切段。

```js
await env.capabilities['voice-activity-detection']({
  audio,                 // {bytes, mimeType}，必填：要检测的录音
})
// -> { speech: Array<{ start_sec: number, end_sec: number }>, model?: string }
```

- `speech` 按时间先后排，互不重叠，每一项 `0 <= start_sec < end_sec`，不超过录音的时长（末尾超出不到 0.05 秒算舍入误差）；一段说话的都没有就是空数组。库会检查，不合格抛 `capability_result_invalid`，`details.problem` 是 `speech_invalid`，`details.index` 是出问题的那一项（整个返回不对就没有），不猜，也不退回按能量切。
- 它只说哪里有人在说话，切成多长一段由库定（`lib/long-recording.mjs` 把它给的区间当作 `../tools/silence-split.mjs` 里「有声音的区间」，后面的合并、长度上限、硬切都一样）。
- 没有这项能力的环境，库用 `../tools/silence-split.mjs` 按能量找静音。

## 只有部分环境能提供的

有些能力不是每个环境都有，别的地方会用到，先在这里定下名字：

- `voice-design` 等：谁的票先用谁定，定了写到这里。

## 文字

### `text-generation`

按文字提示生成文字（大语言模型）。按台词挑参考时让它判断每句的情绪、风格（`lib/reference-pick.mjs`）；润色、翻译、写配音指引也用它。

```js
await env.capabilities['text-generation']({
  prompt,                // string，必填：给模型的文字提示（非空）
})
// -> { text: string, model?: string }
```

- `text` 是模型的回答原文，库自己解析：按台词挑参考要求回答是一个 JSON 数组，读不出来就不采纳、不猜（`judge.status` 是 `unusable`）。
- 环境没有这项能力时，按台词挑参考不判断，用默认参考；这不是错误。

## 怎么念

### `style-instruction`

不是函数，是**声明**：环境提供它，表示合成能力（`text-to-speech`、`voice-cloning`）会按 `instructions` 里的自然语言说明调整语气、节奏、情绪。在 `env.capabilities['style-instruction']` 里放 `true`（或任何不是 `undefined`、`null`、`false` 的值）。

- 库用 `hasCapability(env, 'style-instruction')` 问：有，配音就把配音指引（和这一句的舞台提示）通过 `instructions` 传给合成能力；没有，**整个不传 `instructions`** 这个键，照常合成，并在返回值里说明没传和原因（`unit.instructions.reason` 是 `style_instruction_missing`）。
- 为什么用声明而不是看合成能力「收不收」`instructions`：合成能力的签名里 `instructions` 一直是可选的，没有 `style-instruction` 的环境会忽略它；这样「传了没效果」和「没传」分得开。

## 变声和唱歌

### `voice-conversion`、`singing-voice-conversion`

把一段音频换成另一个声音，内容、节奏（唱歌是旋律和歌词）不变。前者用于说话，后者用于歌声（输入应当是人声分轨，没有伴奏）。

```js
await env.capabilities['voice-conversion']({        // singing-voice-conversion 的签名相同
  audio,                 // {bytes, mimeType}，必填：要换声音的那段
  ref_audio,             // {bytes, mimeType}，必填：目标声音的参考（包里挑出来的一段）
  ref_text,              // string，可选：参考音频的逐字文本，用不上的环境可以忽略
  enhancers,             // 增强件的数组，可选，见下
})
// -> { bytes: Uint8Array, mimeType: string, model?: string, enhancers_used?: string[] }
```

- 用到它们的是 `lib/convert.mjs`（`convertAudio`）。缺哪一项，只有对应的变声报 `capability_missing`，别的功能照常。

## 增强件

增强件是包里只对某个模型有效的文件（微调权重、LoRA、RVC 或 SVC 模型、说话人嵌入），包不依赖它。配音（`voice-cloning`）和变声会把包里**服务这项能力**（清单里增强件的 `capability`）的增强件递给能力：

```js
enhancers: [{ id, model, modelVersion, capability, referenceVersion, load }]   // load() -> Promise<Uint8Array>，用到才读（文件和清单对不对得上，进入环境时检查过，这里不再算）
```

- 能力是环境提供的，只有它知道自己跑的是哪个模型：认识增强件的 `model`（和 `modelVersion`）就 `await load()` 用上，并在返回值里写 `enhancers_used: [用上的增强件的 id]`；不认识就忽略 `enhancers`，照常生成，不报错。
- 报了没有递给它的 id、或 `enhancers_used` 不是数组，库抛 `capability_result_invalid`（`details.problem` 是 `enhancers_used_invalid`），不猜。
- 一个都没用上、而包里有增强件时，库在返回值里写 `enhancers.statement: 'enhancers_not_used'`，附上没用上的增强件是哪个模型的，和包的验证记录，让人知道当前环境下效果会差多少（`lib/enhancers.mjs`）。
