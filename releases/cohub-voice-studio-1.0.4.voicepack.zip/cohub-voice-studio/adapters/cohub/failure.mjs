// SPDX-License-Identifier: Apache-2.0
//
// Cohub 的失败和异常回答怎么分类：哪些算「服务暂时出错」（稍后重新来过也许就成），回答是不是被模型的服务商拦下了。
// 一条规则一处写，Cohub 适配器（env.mjs）和调用方都用它，不各写一份。
// 重不重试、等多久、重试时重建任务还是接着等同一个任务，由调用方定（env.mjs 文件头「重试」一节写了适配器自己的选择）；这里只回答「算不算暂时出错」。
// 例如 app 配音时，一句话的生成任务暂时失败了，就为这一句重新建任务（vs3/src/lib/generation-retry.ts），判断用的就是这里的规则。
// 注意：算「暂时出错」只说明稍后重来也许就成，不是说可以重建任务。建任务那一步失败时，Cohub 那头可能已经建好了任务、已经计费，重建会重复收费：
// 适配器不重试建任务，app 配音也只在手里有任务号时才重试。
//
//   isTransientStatus(status)  HTTP 状态：408、425、429、5xx 算暂时出错。请求自己的状态和任务失败时服务商回的状态都用这一条
//   isTransient(error)         一个失败算不算暂时出错（规则见函数上的说明）
//   taskFailure(error)         任务在 Cohub 那头失败了：从 SDK 抛的那段文字里读出服务商回的状态，返回带 transient 的错误；认不出返回 null
//   blockedByProvider(text)    听音频的补全拿回来的回答，是不是模型的服务商用内容过滤拦下的（回答的位置上是服务商自己的一句说明，不是模型的回答）：
//                              是就返回 { provider, notice }（服务商的名字，小写；回答里从那句说明开始的文字），不是返回 null。认的说法见函数上的说明
//
// 怎么接（env.mjs 的 generate 就是这样接的）：
//   - 建任务失败（HTTP 错误、网络错误）：isTransient(error)
//   - 等结果时失败：isTransient(taskFailure(error) ?? error)。任务本身失败时 SDK（@neta-art/cohub 的 generations.wait）只抛一段文字，
//     服务商的状态在文字里，taskFailure 把它读出来；读不出来的任务失败（例如只有 fetch failed）照旧不算暂时出错
//   - 听音频的补全拿到回答：blockedByProvider(回答的文字)，是被拦下的就抛 provider_blocked（env.mjs 的 complete）。它不是「服务暂时出错」：
//     同一段录音再问还是被拦，所以不带 transient
//
// 模块约定见 protocol/README.md：只用平台自带的 API，浏览器和 Node 都能跑；适配器只依赖核心层。
import { isVoicePackError } from '../../protocol/lib/errors.mjs';

/** HTTP 状态里哪些算服务暂时出错：408、425、429、5xx。请求自己的状态和任务失败时服务商回的状态都用这一条。 */
export const isTransientStatus = (status) => status === 408 || status === 425 || status === 429 || status >= 500;
/** 没有 HTTP 状态的网络错误带的错误码（Node 的 undici 和系统调用）。 */
const NETWORK_CODES = new Set(['UND_ERR_CONNECT_TIMEOUT', 'UND_ERR_HEADERS_TIMEOUT', 'UND_ERR_BODY_TIMEOUT', 'UND_ERR_SOCKET', 'ECONNRESET', 'ECONNREFUSED', 'ECONNABORTED', 'ETIMEDOUT', 'ENOTFOUND', 'EAI_AGAIN', 'EPIPE']);
/** 瞬时的传输错误：没有 HTTP 状态的网络错误，或 isTransientStatus 的状态。别的（4xx、超时、我们自己的 VoicePackError）都不是。带 transient 布尔值的错误（转写网关的、taskFailure 的）以它为准。 */
export function isTransient(error) {
  if (isVoicePackError(error)) return false;
  if (typeof error?.transient === 'boolean') return error.transient;
  if (Number.isInteger(error?.status)) return isTransientStatus(error.status);
  for (let cause = error, depth = 0; cause !== null && typeof cause === 'object' && depth < 5; cause = cause.cause, depth++) {
    if (NETWORK_CODES.has(cause.code)) return true;
  }
  // 浏览器和没带错误码的实现：fetch 连不上时抛的是 TypeError
  return error instanceof TypeError && /fetch failed|failed to fetch|networkerror|network request failed|load failed/i.test(String(error.message));
}
/**
 * 等结果时任务在 Cohub 那头失败了。SDK（@neta-art/cohub 的 generations.wait）这时只抛一段文字：任务的 errorMessage，换行，一行任务号。
 * Cohub 写服务商的失败是「Generation provider is temporarily unavailable — HTTP 502 — details …」「Generation provider request failed — HTTP 400 — details …」
 * （2026-10-16 读 Space 里 18 条失败的生成任务：15 条 502、504，2 条 400，1 条只有 fetch failed）。认得出这种写法，就按服务商回的状态用 isTransientStatus 标：
 * 返回一个带 transient 的错误，原来的错误在 cause 里；不带 status（那是服务商的状态，不是这次请求的，401 也不拦后面的调用）。认不出返回 null，照旧不算暂时出错。
 * 任务已经失败了，再等同一个任务也是同样的结果：这里只给最后报错用，不进 repeat 的重试判断。
 */
const PROVIDER_FAILURE_RE = /^Generation provider\b[^\n]*?\bHTTP (\d{3})\b/;
export function taskFailure(error) {
  if (isVoicePackError(error) || typeof error?.message !== 'string') return null;
  const found = PROVIDER_FAILURE_RE.exec(error.message);
  if (found === null) return null;
  return Object.assign(new Error(error.message, { cause: error }), { transient: isTransientStatus(Number(found[1])) });
}

/**
 * 听音频的补全拿回来的回答，是不是模型的服务商的内容过滤拦下的。服务商拦下时，回答的位置上是它自己的一句说明，不是模型的回答。
 * 返回 { provider, notice }：provider 是服务商的名字（小写），notice 是回答里从那句说明开始的文字（前面模型已经写出来的半截 JSON 不在里面）；不是被拦下的返回 null。
 *
 * 认的是服务商的原话，所以只认见过的说法；换了服务商、或它改了说法，在 BLOCKED_NOTICES 里加一行（不用改别处）：
 *   - 「This request was blocked by Gemini's filters. They can occasionally trigger by mistake on safe coding, security, or biology-related queries. …」
 *     2026-10-16 在 Cohub 上实测（票 34）：同样 12 段录音问两遍，同样 4 段被拦，模型是 gemini-3.8-flash，素材是新闻朗读（复述现成的文章）。
 *     回答照常回来，没有 HTTP 错误（所以只能看回答的文字）。见过两种写法：整段回答就是这句说明；
 *     JSON 回答才写了个开头（{"transcript）就被截断，说明直接接在后面。所以在整段回答里找这句话，不要求它在开头。
 *     撇号用「任意一个字符」认：中转或排版常把直撇号换成弯的（U+2019）；大小写不分。
 * 找的是这一句话，不是 blocked、filters 这样的词：模型自己的回答（转写、对声音的描述）里碰巧有这些词，不能算被拦下。
 * 已知的边界：录音里的人恰好念出这整句英文，转写里就有这句话，会被当成被拦下。这样的素材几乎不可能出现，不为它多写一套判断。
 * @param {string} text 回答的文字
 * @returns {{ provider: string, notice: string } | null}
 */
const BLOCKED_NOTICES = [{ provider: 'gemini', pattern: /This request was blocked by Gemini.s filters/i }];
export function blockedByProvider(text) {
  if (typeof text !== 'string') return null;
  for (const { provider, pattern } of BLOCKED_NOTICES) {
    const found = pattern.exec(text);
    if (found !== null) return { provider, notice: text.slice(found.index) };
  }
  return null;
}
