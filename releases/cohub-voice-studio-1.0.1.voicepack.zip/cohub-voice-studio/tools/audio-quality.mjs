// SPDX-License-Identifier: Apache-2.0
//
// 音质检查：量一段音频的时长、采样率、削波、静音占比、响度（外加底噪），给出能不能当参考音频的结论和原因。只做计算，不用模型。
// 规格对参考集的建议是：每段 5–20 秒，干净，不带伴奏。这里把它落成可以量的数，数值（REFERENCE_THRESHOLDS）是这份实现定的，依据写在下面。
//
// 三个函数，分开用也行：
//   measureAudio(audio)                       量。audio 是解码出来的 { sampleRate, samples: Float32Array[] }（decodeAudio 的结果可以直接给）
//   judgeReference(metrics, thresholds?)      判。metrics 是 measureAudio 的结果
//   checkAudioQuality(env, bytes, options?)   解码（audio-decode.mjs，非 WAV 要环境里的 ffmpeg）、量、判，一步到位
// 另外导出 REFERENCE_THRESHOLDS（阈值）和 kWeightingCoefficients（响度用的 K 计权滤波器的系数）。
//
// ---------------------------------------------------------------- 量出来的数（measureAudio）
//   durationSec     帧数 / 采样率，保留到毫秒
//   sampleRate      Hz
//   channels        声道数
//   peakDbfs        所有声道里绝对值最大的采样，dBFS（满幅 1.0 是 0 dBFS）；全 0 记 −120。保留 0.1 dB
//   clipping        { samples, ratio }：落在平顶里的采样个数，和它占全部采样（所有声道）的比例（保留到 1e-6）。
//                   平顶 = 同一个声道里连续 3 个以上、同一个方向（都正或都负）、绝对值 ≥ 0.999（约 −0.01 dBFS）的采样
//   silenceRatio    静音占比：声道平均成单声道，每 20 毫秒一个窗口（不足一个窗口的零头不算），窗口的有效值（RMS）低于 −50 dBFS 就算静音，
//                   静音窗口占全部窗口的比例（保留到 1e-4）；一个完整的窗口都没有（短于 20 毫秒）记 null
//   noiseFloorDbfs  底噪估计：同样的窗口里，最安静的 10% 的窗口的电平（窗口电平从小到大排，取 10% 位置上的那一个），dBFS，全 0 记 −120。
//                   它反映停顿里和字词之间的背景有多响；一个完整的窗口都没有记 null。保留 0.1 dB
//   loudnessLufs    整体响度，ITU-R BS.1770-4：K 计权（两级滤波，系数在 48 kHz 时和标准给的表一致，别的采样率按同样的公式算），
//                   400 毫秒的块、每次错开 100 毫秒，绝对门限 −70 LUFS，相对门限比绝对门限之后的平均低 10 LU，各声道的权重都是 1
//                   （一个单声道文件按单声道算，997 Hz 的满幅正弦是 −3.01 LUFS；不认声道布局，多于两个声道时每个声道权重都是 1）。
//                   短于 400 毫秒、或者所有的块都低于绝对门限（几乎是静音）记 null。保留 0.1 LU
// 数值都是 JSON 能表示的（没有 Infinity 和 NaN）。「判」看的是这些保留后的数，所以报告里写的数和结论总是一致的。
//
// ---------------------------------------------------------------- 阈值和依据（REFERENCE_THRESHOLDS）
// 「提醒」（warn）：能用，但最好先处理或者留意。「拒绝」（reject）：不能直接当参考。区间都是闭区间在「好」的一边：5 秒和 20 秒本身没问题。
//
//   量              提醒                           拒绝
//   时长            < 5 秒，或 > 20 秒             < 3 秒，或 > 30 秒
//   采样率          < 16000 Hz                     < 12000 Hz
//   削波比例        ≥ 0.1%                         ≥ 1%
//   静音占比        > 30%                          > 60%
//   整体响度        < −35 LUFS，或 > −10 LUFS      < −55 LUFS，或量不出来（所有的块都低于 −70 LUFS）
//   底噪            > −40 dBFS                     （只提醒）
//
//   时长     5–20 秒是规格的建议。拒绝线取 3 秒和 30 秒：短于 3 秒装不下一句完整的话，语气和音色都带不出来；
//            长于 30 秒已经远超建议，应当先切成段（做包的流程先切再判）。
//   采样率   录音里最高的频率是采样率的一半：16 kHz 的录音没有 8 kHz 以上的部分。但 16 kHz 是语音常用的采样率：公开语料（LibriSpeech、AISHELL-1）、
//            转写网关、05b 标定用的说话人相似度模型吃的都是 16 kHz；05b 里克隆的参考就是这类 16 kHz 的语料录音，克隆出来的声音和留出录音的说话人相似度
//            是真人基线的 0.83（平均，12 次克隆，没有更高采样率的参考做对照）。所以提醒线放在 16000，低于它的提醒；电话音频（8 kHz）和 11.025 kHz 的录音
//            高频缺得更多，克隆出来会闷，拒绝线是 12000。
//            2026-10-15 校准（票 14）：82 条 16 kHz 的公开语料录音（好的和各种坏的都有）里，旧的提醒线 22050 把它们全部提醒了，一点区分力都没有，所以下调。
//            没有拿低于 16 kHz 的真实录音试过 12000 和 16000 这两条线，也没有量过 16 kHz 的参考比更高采样率的参考克隆得差多少：这两条线靠上面的依据，不是实测。
//   削波     硬削波的特征是平顶：波形被削掉以后，连续几个采样顶在数字上限上。所以量的是「连续 3 个以上顶在上限的采样」，不是「碰到上限的采样」：
//            单个碰到满幅的采样很常见，把峰值调到满幅的健康录音有，持续的元音和正弦波每个周期都有（满幅的正弦有 2.8% 的采样在 0.999 以上，
//            却一点没削波）；平顶要连续好几个。比例上，千分之一提醒，百分之一已经是严重失真。
//            只认顶在数字上限（≥ 0.999）的平顶：削掉以后又整体调低了的录音，平顶不在上限，这里看不出来。
//   静音     自然的朗读，停顿占一到三成；超过三成，能听出音色的部分太少；超过六成基本是空的。整段全 0 是 100%。
//            −50 dBFS 比常见的房间底噪（−60 到 −70 dBFS）高，比说话（有效值 −20 到 −35 dBFS）低得多，能把两者分开。
//   响度     广播的语音是 −23 LUFS（EBU R128），播客常见 −16 LUFS，所以 −35 到 −10 是宽松的正常范围。
//            低于 −35 太轻：调高就会把噪声一起调高（做包的流程会统一调响度：lib/make-pack.mjs 在量完、挑好素材以后，把写进包里的参考和留出录音统一到 −23 LUFS，
//            tools/loudness-normalize.mjs；所以这里只是提醒）；低于 −55 和底噪没有区别，不能用。
//            高于 −10 的语音几乎一定是压得很狠或者削波了。
//   底噪     最安静的一成窗口还高于 −40 dBFS，说明整段都有持续的背景：噪声、房间声，或者背景音乐。
//            这个量分不清噪声和伴奏，也量不出人声以外的东西到底是什么，所以只提醒，结论要听一下才下。
//            这是在题目的五项（时长、削波、静音占比、响度、采样率）之外多加的一项：规格要求「干净、不带伴奏」，前五项量不出这一点。
//
// 这些阈值是按常见做法定的，用合成的信号验过算术（tests/voicepack/tools-audio-quality.test.mjs），响度还和 ffmpeg 的 ebur128 滤镜对过。
// 采样率的提醒线经真实录音校准（票 14，2026-10-15，82 条 16 kHz 的公开语料录音），其他指标的阈值沿用 09 的定；调整要拿真实录音试。
// 改阈值数值时，改 REFERENCE_THRESHOLDS 和这张表，别的地方不写数。调用方可以只覆盖其中一部分：judgeReference(metrics, { duration: { warnAbove: 30 } })，没写的限值照旧。
//
// ---------------------------------------------------------------- 结论（judgeReference）
//   { verdict: 'ok' | 'warn' | 'reject', usable: boolean, reasons: [{ code, severity: 'warn' | 'reject', message, value, limit }] }
//   verdict   有一条拒绝就是 'reject'，只有提醒是 'warn'，什么都没有是 'ok'。usable = verdict !== 'reject'。
//   reasons   按检查的顺序（时长、采样率、削波、静音、响度、底噪）；value 是量出来的数，limit 是越过的那条线；message 是给人看的中文，说明原因和怎么办。
//   code      duration_too_short  duration_short  duration_long  duration_too_long
//             sample_rate_too_low  sample_rate_low
//             clipping_severe  clipping
//             silence_dominant  silence_high
//             loudness_inaudible  loudness_unmeasured  loudness_too_low  loudness_low  loudness_high
//             noise_floor_high
//
// 模块约定见 protocol/README.md：只用平台自带的 API，浏览器和 Node 都能跑。
import { decodeAudio } from './audio-decode.mjs';

const FLOOR_DB = -120; // 全 0 的电平：不用 -Infinity，JSON 表示不了
const CLIP_LEVEL = 0.999;
const CLIP_RUN = 3;
export const WINDOW_SECONDS = 0.02;
const SILENCE_DBFS = -50;
const NOISE_PERCENTILE = 0.1;
const LOUDNESS_BLOCK_SECONDS = 0.4;
const LOUDNESS_HOP_SECONDS = 0.1;
const LOUDNESS_ABSOLUTE_GATE = -70;
const LOUDNESS_RELATIVE_GATE = -10;

const deepFreeze = (value) => {
  for (const inner of Object.values(value)) if (inner && typeof inner === 'object') deepFreeze(inner);
  return Object.freeze(value);
};

/** 阈值的默认值，依据见文件头。分组的名字就是 judgeReference 覆盖时用的名字。 */
export const REFERENCE_THRESHOLDS = deepFreeze({
  duration: { rejectBelow: 3, warnBelow: 5, warnAbove: 20, rejectAbove: 30 },
  sampleRate: { rejectBelow: 12000, warnBelow: 16000 },
  clippingRatio: { warnAtOrAbove: 0.001, rejectAtOrAbove: 0.01 },
  silenceRatio: { warnAbove: 0.3, rejectAbove: 0.6 },
  loudnessLufs: { rejectBelow: -55, warnBelow: -35, warnAbove: -10 },
  noiseFloorDbfs: { warnAbove: -40 },
});

const round = (x, digits) => {
  const k = 10 ** digits;
  return Math.round(x * k) / k;
};
const toDb = (amplitude) => (amplitude > 0 ? Math.max(FLOOR_DB, 20 * Math.log10(amplitude)) : FLOOR_DB);

export function checkedAudio(audio) {
  const ok =
    audio !== null && typeof audio === 'object' &&
    Number.isInteger(audio.sampleRate) && audio.sampleRate > 0 &&
    Array.isArray(audio.samples) && audio.samples.length > 0 &&
    audio.samples.every((s) => s !== null && typeof s === 'object' && typeof s.length === 'number' && s.length === audio.samples[0].length);
  if (!ok) throw new TypeError('audio 必须是 { sampleRate: 正整数, samples: 至少一个声道的数组，每个声道一样长 }');
  return audio;
}

// ---------------------------------------------------------------- 响度（ITU-R BS.1770-4）

// K 计权：第 1 级是高频搁架（+4 dB 左右），第 2 级是 RLB 高通（约 38 Hz）。参数是标准给的模拟原型，
// 按双线性变换算出任意采样率的系数；48 kHz 时和标准的表 1、表 2 一致（测试里逐项核对，差在 1e-9 以内）。
/**
 * K 计权两级滤波器的系数，写法同标准的表：b = [b0, b1, b2]，a = [1, a1, a2]。
 * @param {number} sampleRate Hz
 * @returns {[{ b: number[], a: number[] }, { b: number[], a: number[] }]} [高频搁架, RLB 高通]
 */
export function kWeightingCoefficients(sampleRate) {
  const k1 = Math.tan((Math.PI * 1681.974450955533) / sampleRate);
  const q1 = 0.7071752369554196;
  const vh = 10 ** (3.999843853973347 / 20);
  const vb = vh ** 0.4996667741545416;
  const d1 = 1 + k1 / q1 + k1 * k1;
  const shelf = {
    b: [(vh + (vb * k1) / q1 + k1 * k1) / d1, (2 * (k1 * k1 - vh)) / d1, (vh - (vb * k1) / q1 + k1 * k1) / d1],
    a: [1, (2 * (k1 * k1 - 1)) / d1, (1 - k1 / q1 + k1 * k1) / d1],
  };
  const k2 = Math.tan((Math.PI * 38.13547087602444) / sampleRate);
  const q2 = 0.5003270373238773;
  const d2 = 1 + k2 / q2 + k2 * k2;
  const highpass = { b: [1, -2, 1], a: [1, (2 * (k2 * k2 - 1)) / d2, (1 - k2 / q2 + k2 * k2) / d2] };
  return [shelf, highpass];
}

const powerToLufs = (power) => -0.691 + 10 * Math.log10(power);

// 整体响度，LUFS；短于一个块、或者所有的块都低于绝对门限，返回 null。不取整：tools/loudness-normalize.mjs 要用精确值
export function integratedLoudness(samples, rate) {
  const hop = Math.max(1, Math.round(rate * LOUDNESS_HOP_SECONDS));
  const perBlock = Math.max(1, Math.round(LOUDNESS_BLOCK_SECONDS / LOUDNESS_HOP_SECONDS));
  const frames = samples[0].length;
  const segments = Math.floor(frames / hop);
  if (segments < perBlock) return null;
  const [shelf, highpass] = kWeightingCoefficients(rate);
  const [sb0, sb1, sb2] = shelf.b;
  const [, sa1, sa2] = shelf.a;
  const [hb0, hb1, hb2] = highpass.b;
  const [, ha1, ha2] = highpass.a;
  const energy = new Float64Array(segments); // 每 100 毫秒一段：所有声道经过 K 计权以后的平方和
  for (const channel of samples) {
    let x1 = 0, x2 = 0, y1 = 0, y2 = 0; // 第 1 级的状态
    let u1 = 0, u2 = 0, w1 = 0, w2 = 0; // 第 2 级的状态
    for (let s = 0; s < segments; s++) {
      let sum = 0;
      for (let i = s * hop, end = i + hop; i < end; i++) {
        const x = channel[i];
        const y = sb0 * x + sb1 * x1 + sb2 * x2 - sa1 * y1 - sa2 * y2;
        x2 = x1; x1 = x; y2 = y1; y1 = y;
        const w = hb0 * y + hb1 * u1 + hb2 * u2 - ha1 * w1 - ha2 * w2;
        u2 = u1; u1 = y; w2 = w1; w1 = w;
        sum += w * w;
      }
      energy[s] += sum;
    }
  }
  const blocks = segments - perBlock + 1;
  const power = new Float64Array(blocks); // 每个块的平均功率（各声道权重都是 1）
  for (let j = 0; j < blocks; j++) {
    let sum = 0;
    for (let k = 0; k < perBlock; k++) sum += energy[j + k];
    power[j] = sum / (perBlock * hop);
  }
  const mean = (keep) => {
    let sum = 0;
    let n = 0;
    for (let j = 0; j < blocks; j++) if (keep(j)) { sum += power[j]; n++; }
    return n === 0 ? null : sum / n;
  };
  const afterAbsolute = mean((j) => power[j] > 0 && powerToLufs(power[j]) > LOUDNESS_ABSOLUTE_GATE);
  if (afterAbsolute === null) return null;
  const relativeGate = powerToLufs(afterAbsolute) + LOUDNESS_RELATIVE_GATE;
  const afterRelative = mean((j) => power[j] > 0 && powerToLufs(power[j]) > LOUDNESS_ABSOLUTE_GATE && powerToLufs(power[j]) > relativeGate);
  return afterRelative === null ? null : powerToLufs(afterRelative);
}

// ---------------------------------------------------------------- 量

// 每 20 毫秒一个窗口的电平（dBFS，声道平均成单声道以后的有效值）
// 每 20 毫秒一个窗口的电平（dBFS，声道平均成单声道以后的有效值）。导出给 silence-split.mjs 用：它找静音用的是同一把尺，不另写一份
export function windowLevels(samples, rate) {
  const size = Math.max(1, Math.round(rate * WINDOW_SECONDS));
  const count = Math.floor(samples[0].length / size);
  const channels = samples.length;
  const levels = new Float64Array(count);
  for (let w = 0; w < count; w++) {
    let sum = 0;
    for (let i = w * size, end = i + size; i < end; i++) {
      let mono = 0;
      for (let c = 0; c < channels; c++) mono += samples[c][i];
      mono /= channels;
      sum += mono * mono;
    }
    levels[w] = toDb(Math.sqrt(sum / size));
  }
  return levels;
}

// 平顶里的采样个数：每个声道各自找，连续 CLIP_RUN 个以上、同一个方向、绝对值 ≥ CLIP_LEVEL 的一段算一个平顶
function clippedSamples(samples, frames) {
  let clipped = 0;
  for (const channel of samples) {
    let run = 0;
    let direction = 0;
    for (let i = 0; i < frames; i++) {
      const v = channel[i];
      const d = v >= CLIP_LEVEL ? 1 : v <= -CLIP_LEVEL ? -1 : 0;
      if (d !== 0 && d === direction) run++;
      else {
        if (run >= CLIP_RUN) clipped += run;
        run = d !== 0 ? 1 : 0;
        direction = d;
      }
    }
    if (run >= CLIP_RUN) clipped += run;
  }
  return clipped;
}

/**
 * 量一段音频。每一项的定义见文件头。
 * @param {{ sampleRate: number, samples: ArrayLike<number>[] }} audio decodeAudio 的结果可以直接给
 * @returns {{ durationSec: number, sampleRate: number, channels: number, peakDbfs: number, clipping: { samples: number, ratio: number }, silenceRatio: number|null, noiseFloorDbfs: number|null, loudnessLufs: number|null }}
 * @throws {TypeError} audio 的形状不对
 */
export function measureAudio(audio) {
  const { sampleRate, samples } = checkedAudio(audio);
  const channels = samples.length;
  const frames = samples[0].length;
  let peak = 0;
  for (const channel of samples) {
    for (let i = 0; i < frames; i++) {
      const a = Math.abs(channel[i]);
      if (a > peak) peak = a;
    }
  }
  const clipped = clippedSamples(samples, frames);
  const levels = windowLevels(samples, sampleRate);
  let silenceRatio = null;
  let noiseFloorDbfs = null;
  if (levels.length > 0) {
    let silent = 0;
    for (const level of levels) if (level < SILENCE_DBFS) silent++;
    silenceRatio = round(silent / levels.length, 4);
    const sorted = Float64Array.from(levels).sort();
    noiseFloorDbfs = round(sorted[Math.floor((sorted.length - 1) * NOISE_PERCENTILE)], 1);
  }
  const loudness = integratedLoudness(samples, sampleRate);
  return {
    durationSec: round(frames / sampleRate, 3),
    sampleRate,
    channels,
    peakDbfs: round(toDb(peak), 1),
    clipping: { samples: clipped, ratio: round(clipped / (frames * channels || 1), 6) },
    silenceRatio,
    noiseFloorDbfs,
    loudnessLufs: loudness === null ? null : round(Math.max(FLOOR_DB, loudness), 1),
  };
}

// ---------------------------------------------------------------- 判

function mergedThresholds(overrides) {
  if (overrides === null || typeof overrides !== 'object' || Array.isArray(overrides)) throw new TypeError('thresholds 必须是对象，例如 { duration: { warnAbove: 30 } }');
  const merged = {};
  for (const group of Object.keys(overrides)) {
    if (!(group in REFERENCE_THRESHOLDS)) throw new TypeError(`thresholds 里没有 ${group} 这一组（有：${Object.keys(REFERENCE_THRESHOLDS).join('、')}）`);
    for (const limit of Object.keys(overrides[group] ?? {})) {
      if (!(limit in REFERENCE_THRESHOLDS[group])) throw new TypeError(`thresholds.${group} 里没有 ${limit} 这条线（有：${Object.keys(REFERENCE_THRESHOLDS[group]).join('、')}）`);
    }
  }
  for (const group of Object.keys(REFERENCE_THRESHOLDS)) merged[group] = { ...REFERENCE_THRESHOLDS[group], ...(overrides[group] ?? {}) };
  return merged;
}

const pct = (ratio) => `${round(ratio * 100, 2)}%`;

function judge(metrics, t) {
  const need = ['durationSec', 'sampleRate', 'clipping', 'silenceRatio', 'noiseFloorDbfs', 'loudnessLufs'];
  if (metrics === null || typeof metrics !== 'object' || need.some((k) => !(k in metrics)) || metrics.clipping === null || typeof metrics.clipping !== 'object') {
    throw new TypeError(`metrics 必须是 measureAudio 的结果（要有 ${need.join('、')}）`);
  }
  const reasons = [];
  const add = (code, severity, message, value, limit) => reasons.push({ code, severity, message, value, limit });
  const { durationSec: dur, sampleRate: rate, silenceRatio: silence, noiseFloorDbfs: noise, loudnessLufs: loud } = metrics;
  const clip = metrics.clipping.ratio;

  const d = t.duration;
  if (dur < d.rejectBelow) add('duration_too_short', 'reject', `时长 ${dur} 秒，短于 ${d.rejectBelow} 秒：装不下一句完整的话，语气和音色都带不出来，不能当参考`, dur, d.rejectBelow);
  else if (dur < d.warnBelow) add('duration_short', 'warn', `时长 ${dur} 秒，短于建议的 ${d.warnBelow} 秒：能用，但内容少，最好换一段更长的`, dur, d.warnBelow);
  if (dur > d.rejectAbove) add('duration_too_long', 'reject', `时长 ${dur} 秒，长于 ${d.rejectAbove} 秒：先切成 ${d.warnBelow}–${d.warnAbove} 秒的段再用`, dur, d.rejectAbove);
  else if (dur > d.warnAbove) add('duration_long', 'warn', `时长 ${dur} 秒，长于建议的 ${d.warnAbove} 秒：最好切短`, dur, d.warnAbove);

  const s = t.sampleRate;
  if (rate < s.rejectBelow) add('sample_rate_too_low', 'reject', `采样率 ${rate} Hz，低于 ${s.rejectBelow} Hz：高频缺得太多（电话音质），克隆出来会发闷，不能当参考`, rate, s.rejectBelow);
  else if (rate < s.warnBelow) add('sample_rate_low', 'warn', `采样率 ${rate} Hz，低于 ${s.warnBelow} Hz：${rate / 2} Hz 以上的高频没有，音色会暗一些；有更高采样率的原声就用原声`, rate, s.warnBelow);

  const c = t.clippingRatio;
  if (clip >= c.rejectAtOrAbove) add('clipping_severe', 'reject', `削波严重：${pct(clip)} 的采样在平顶上（${metrics.clipping.samples} 个顶在满幅），声音已经失真，不能当参考`, clip, c.rejectAtOrAbove);
  else if (clip >= c.warnAtOrAbove) add('clipping', 'warn', `有削波：${pct(clip)} 的采样在平顶上（${metrics.clipping.samples} 个顶在满幅），会带进失真；能重录就重录，或者换一段`, clip, c.warnAtOrAbove);

  const q = t.silenceRatio;
  if (silence !== null) {
    if (silence > q.rejectAbove) add('silence_dominant', 'reject', `静音占 ${pct(silence)}，超过 ${pct(q.rejectAbove)}：基本是空的，能听出音色的部分太少，不能当参考`, silence, q.rejectAbove);
    else if (silence > q.warnAbove) add('silence_high', 'warn', `静音占 ${pct(silence)}，超过 ${pct(q.warnAbove)}：停顿太多，有效的说话时间短；最好裁掉长停顿`, silence, q.warnAbove);
  }

  const l = t.loudnessLufs;
  if (loud === null) {
    if (dur >= LOUDNESS_BLOCK_SECONDS) add('loudness_inaudible', 'reject', `整段都低于 ${LOUDNESS_ABSOLUTE_GATE} LUFS：几乎听不见，不能当参考`, null, LOUDNESS_ABSOLUTE_GATE);
    else add('loudness_unmeasured', 'warn', `短于 ${LOUDNESS_BLOCK_SECONDS} 秒，量不出响度`, null, LOUDNESS_BLOCK_SECONDS);
  } else if (loud < l.rejectBelow) add('loudness_too_low', 'reject', `响度 ${loud} LUFS，低于 ${l.rejectBelow} LUFS：和底噪差不多，不能当参考`, loud, l.rejectBelow);
  else if (loud < l.warnBelow) add('loudness_low', 'warn', `响度 ${loud} LUFS，低于 ${l.warnBelow} LUFS：太轻，调高响度时噪声也会被调高；先统一响度，或者换一段`, loud, l.warnBelow);
  else if (loud > l.warnAbove) add('loudness_high', 'warn', `响度 ${loud} LUFS，高于 ${l.warnAbove} LUFS：这么响的人声通常是压得很狠或者削波了；先调低响度`, loud, l.warnAbove);

  const n = t.noiseFloorDbfs;
  if (noise !== null && noise > n.warnAbove) add('noise_floor_high', 'warn', `底噪估计 ${noise} dBFS，高于 ${n.warnAbove} dBFS：整段都有持续的背景（噪声、房间声或背景音乐）；这个量分不清噪声和伴奏，要听一下`, noise, n.warnAbove);

  const verdict = reasons.some((r) => r.severity === 'reject') ? 'reject' : reasons.length > 0 ? 'warn' : 'ok';
  return { verdict, usable: verdict !== 'reject', reasons };
}

/**
 * 按阈值给出结论。
 * @param {ReturnType<typeof measureAudio>} metrics measureAudio 的结果
 * @param {{ [group: string]: { [limit: string]: number } }} [thresholds] 要覆盖的阈值，没写的用 REFERENCE_THRESHOLDS
 * @returns {{ verdict: 'ok'|'warn'|'reject', usable: boolean, reasons: { code: string, severity: 'warn'|'reject', message: string, value: number|null, limit: number|null }[] }}
 * @throws {TypeError} metrics 缺字段，或 thresholds 写了不存在的组和线（写错名字不会悄悄不起作用）
 */
export function judgeReference(metrics, thresholds = {}) {
  return judge(metrics, mergedThresholds(thresholds));
}

/**
 * 解码、量、判，一步到位。
 * @param {object|undefined} env 注入的运行环境；音频是自己能解的 WAV 时可以不给，其他格式要 env.runtimes.ffmpeg（见 audio-decode.mjs）
 * @param {Uint8Array} bytes 音频文件的字节
 * @param {{ thresholds?: object }} [options] thresholds：要覆盖的阈值，写法同 judgeReference；写错名字在解码之前就报，不白解码
 * @returns {Promise<{ decoder: 'wav'|'ffmpeg', metrics: ReturnType<typeof measureAudio>, verdict: string, usable: boolean, reasons: object[] }>}
 * @throws 解码的错（audio_decode_failed、wav_invalid、runtime_missing……）原样抛出，见 audio-decode.mjs
 */
export async function checkAudioQuality(env, bytes, { thresholds = {} } = {}) {
  const merged = mergedThresholds(thresholds);
  const audio = await decodeAudio(env, bytes);
  const metrics = measureAudio(audio);
  return { decoder: audio.decoder, metrics, ...judge(metrics, merged) };
}
