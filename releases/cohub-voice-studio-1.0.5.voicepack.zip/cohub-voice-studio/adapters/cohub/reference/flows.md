# Flows (detailed)

How the Voice Studio app implements the flows that the base part's `SKILL.md` describes by required capability. Model names are the Cohub adapter's (`../capability-map.json`).

## Synthesis pipeline (`vs3/src/lib/tts.ts`, `vs3/src/lib/voicepack/plan.ts`)

```
resolveModel(requested, voices, voicePrompt)
  voicePrompt && no voice URL            -> qwen-audio-3.0-tts-plus
  voices with URL count > 1              -> higgs-tts
  else                                   -> requested || higgs-tts

synthesize({ text, voices, model, voicePrompt, speed, lexicon, cast, watermark, signal, runs, packs })
  1 pronunciation       planJobs (voicepack/plan.ts, voicepack/lexicon.ts): the viewer's dictionary and the lexicon of each voice that speaks
                        (a voice pack's lexicon.pls) become rules, applied in one go by the pack library's applyLexicon
                        (lib/pronunciation-lexicon.mjs); the viewer's way wins for the same term; script markers are left alone
  2 planJobs            chunkText(260) OR scriptSpans (markup / [voice:]); a voice with several references (voice pack) reads each piece
                        between markers for stage directions (lib/line-hints.mjs: brackets the cue vocabulary does not know stay in the text,
                        spoken as written) and picks a reference per line (lib/reference-pick.mjs): the job's voice url is the picked segment
  3 fitMinLength        merge short chunks; qwen needs >= 15 chars
  4 generate            concurrency 2-3; per chunk:
                        generateAudio({ model, text, audio:[{url,weight}], meta:{voice_prompt} })
                        run.id re-attaches a persisted taskRunId (no double billing)
  5 stitch              trimSilence -> fade -> [pause] gaps -> silence 0.12s -> changeSpeed(atempo)
  6 watermark           AudioSeal (optional)
  7 aggregate cost
```

## Clone (`ClonePage.tsx`)

```
input: upload | record | library/take URL
  -> decode -> TrimWaveform [sel]
  -> optional: Remove background (on-device MDX-Net) + normalizeLufs(-20)
  -> transcript: cohubTranscribe | whisper
  -> preview: synthesize(reference)
  -> metadata (name/lang/gender/tags/desc, describeVoice, AI portrait)
  -> save VoiceProfile (useProfiles) ; optional publish -> community.publish('voices')
untouched rule: remote URL used whole -> passed as-is, no re-upload
```

## Design (`DesignPage.tsx`)

```
attrs (CATEGORIES) + extra(timbre/pace/mood) + free text
  -> buildPrompt()  (or designPromptFromText / community preset)
  -> startSpeakJob({ kind:'design', voicePrompt, model:'qwen-audio-3.0-tts-plus' })
  -> candidates -> Lock() stores a reference  (subsequent -> Clone path)
```

## Jobs / resumption (`lib/jobs.ts`)

`startSpeakJob` is a background task. Job input + `runs` (chunk -> taskRunId) persist on the task.
On reload, `registerResumer('speech', ...)` re-attaches to the same runs. Cancelled/interrupted jobs
with a matching signature are reused, so **no double charge**.

## Related flows

- **Stories**: `parseScript` + `splitStoryText` + `storyCast` -> multi-role render.
- **Audiobook**: `audiobookScript` + `render.ts` (per-segment runs cached in `localStorage vs3.runs.*`).
- **Dub**: ASR -> `translateLines` (LLM) -> `fitToDuration` -> TTS -> mix.
- **Transcribe**: `asr.ts` cloud (VAD-segmented `wss://gateway.cohub.live/asr/ws`) or local Whisper;
  subtitles `toSrt` / `toVtt`.
- **Tools**: separate · diarize · convert · compare · fit · direction · watermark · loudness · probe · format.

## Identity & uploads (`lib/cohub.ts`)

`initCohub` reads the runtime viewer; `ensureAI` authorizes viewer scopes on their own Space;
`withAI` recovers 403 (renew -> re-pick). Uploads: `publicAssets.uploadGenerationInput` (viewer-owned,
durable, CORS) -> fallback api-server `POST /api/v1/media`.

## Blend & selection (`components/voice.tsx`)

- A voice's weight is a **share that always sums to 1** (`normalize` / `share`, `MIN_SHARE = 0.05`); moving one slider redistributes the rest proportionally.
- The default voice model accepts **2–16 weighted references**; the picker keeps at most the 6 most recently added.
