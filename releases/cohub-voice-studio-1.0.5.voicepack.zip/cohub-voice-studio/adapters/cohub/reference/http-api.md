# Voice Studio HTTP API

Base: `{{PUBLIC_BASE}}` · OpenAPI: `GET /api/v2/openapi.json` · MCP: `POST /mcp`. Free routes need no
auth; `Bearer $COHUB_TOKEN` routes bill **the caller**.

## Library (free, read-only)

| Method | Path | Notes |
|---|---|---|
| GET | `/api/v1/voices` | `q lang tag gender source sort page pageSize`; `tag` may be given more than once, and a voice has to match every one; ~49k voices |
| GET | `/api/v1/voices/{id}` | one voice |
| GET | `/api/v1/tags` | tags + counts |
| GET | `/api/v1/languages` | languages + counts |
| GET | `/api/v1/stats` | totals |
| GET | `/api/v1/top?limit=` | usage ranking |
| GET | `/api/v1/health` | liveness + `totalVoices` |
| POST | `/api/v1/hit?id=` | usage counter (write-once log) |

## Speech (OpenAI-compatible + JSON)

| Method | Path | Body |
|---|---|---|
| POST | `/v1/audio/speech` | `{ model, voice, input, response_format?, speed? }` → mp3/json |
| GET | `/v1/models` | lists `higgs-tts`, `qwen-audio-3.0-tts-plus`, `tts-1` |
| POST | `/api/v2/tts` | `{ text, voiceId, model? }` → `{ url, cost, taskRunId }` |
| POST | `/api/v1/media` | multipart upload → durable viewer-owned URL |

```bash
curl -X POST {{PUBLIC_BASE}}/v1/audio/speech \
  -H "Authorization: Bearer $COHUB_TOKEN" -H "Content-Type: application/json" \
  -d '{"model":"higgs-tts","voice":"<voice id>","input":"你好"}' -o out.mp3
```

## Community (`/api/v2/community/*`)

`voices | works | presets` — `GET` (public) / `POST` publication (`PATCH`, `DELETE` own).
Plus: `comments`, `counts`, `users/{uuid}`, `users/{uuid}/{followers|following}`,
`creators`, `feed` (auth), `use`, `reports` (auth / own), `moderate` (admin).

### Voice packs

Voices in the community are shared as voice packs. A pack is published as its share file (a `.voicepack.zip`) and
becomes a community voice (`kind: "voice"`) whose `pack` object carries the pack id, the version, the changelog, the
validation records (fidelity ratios, shown as they are) and `downloadUrl`.

| Method | Path | Notes |
|---|---|---|
| POST | `/api/v2/community/packs` | auth; body = the bytes of the share file, `Content-Type: application/vnd.cohub.voicepack+zip` → the community voice |
| GET, HEAD | `/api/v2/community/packs/{packId}/file[?version=x.y.z]` | public; the share file exactly as it was published (the newest version unless `version` is given). The address belongs to the pack id, so it stays good across new versions |

```bash
curl -X POST {{PUBLIC_BASE}}/api/v2/community/packs \
  -H "Authorization: Bearer $COHUB_TOKEN" -H "Content-Type: application/vnd.cohub.voicepack+zip" \
  --data-binary @voice.voicepack.zip
curl -OJ {{PUBLIC_BASE}}/api/v2/community/packs/<packId>/file
```

Publishing is checked with the voice pack library, and the pack is kept only when the check passes. Only the base part
and the protocol core need the official signature; the role part needs none. A share file with only the role part is
checked against the server's own base part. A pack that names external resources is refused: put the files in the pack.

| Status | `error` | Meaning |
|---|---|---|
| 400 | `pack_invalid` | the library found problems; `problems[]` lists each one as `{ code, message, part, details }` |
| 401 | `unauthorized` | no valid Cohub token |
| 403 | `pack_id_taken` | the first account to publish a pack id is its author; only that account can publish new versions |
| 409 | `version_exists`, `version_not_newer` | a published version is never replaced, and a new version must be higher than every published one; `latest` is the highest one published |
| 413 | `payload_too_large` | the file is over the size limit (`limitBytes`) |
| 413 | `pack_quota_exceeded` | all stored versions of the account's packs plus this file would be over the per-author storage limit (`usedBytes`, `limitBytes`, `sizeBytes`); withdrawn voices still count, files are not deleted |
| 415 | `unsupported_media_type` | the `Content-Type` is not the share file's |
| 429 | `rate_limited`, `server_busy` | too many publishes; `server_busy` carries `Retry-After` |

A new version of the same pack id updates the same community voice. A voice that comes from a pack is what its pack
says: `PATCH` accepts only `portrait` and answers `409 pack_managed` (`fields` lists what was refused) for anything
else, so publish a new version to change it. `GET /api/v1/voices` and `/api/v2/community/voices` find pack voices by
`lang` (display name, language code or the full tag, any language the pack speaks), `tag` (the voice library's
Chinese words or the design vocabulary's canonical English names, scene ids, and the library's use-case words that
the product contract maps a scene to) and `q`.

### Public page and embed of a pack (no login)

Every pack in the community has a public address. A pack its author withdrew, or a moderator hid, answers 404 on all of them.

| Method | Path | Notes |
|---|---|---|
| GET, HEAD | `/pack/{packId}` | the pack's public page: HTML the server writes itself (the app renders none of it), with `og:title`, `og:description`, `og:image`, `og:audio` and `twitter:card`, so a social platform's link preview needs no script. The page plays the audition, downloads the share file, shows the embed code and has the "make your own" button. It runs no script and cannot be framed. Not counted. A missing pack is 404 HTML without preview tags |
| GET | `/pack/{packId}/image.png` | the pack's picture, PNG 1200×630, worked out from the pack id (the same id always gives the same picture; cached for 60 seconds, like the page, so after a pack is withdrawn its picture stays in caches that long at most); the page's `og:image` is this one unless the author set a cover |
| POST | `/pack/{packId}/make-your-own` | the form target of the page's button: counts one press, then answers 303 to the app's make-your-own page (`{{APP_URL}}?p=%2Fstudio%2Fmake-your-own&pack=<packId>`). Only a POST counts, a GET is 405, so a platform fetching the page or a browser prefetching the link adds nothing. The server keeps the pack id and a number, not who pressed |
| POST | `/api/v2/community/packs/{packId}/make-your-own` | the app's own button reports a press here (no login, no body; the answer is `{ ok: true, data: { counted: true } }`, no number); counted together with the page's button. 404 and nothing counted for a pack that does not exist or is withdrawn or hidden; a GET is 405 |
| GET | `/embed/pack/{packId}` | the pack's mini player for an `<iframe>` (HTML): plays the pack's default reference recording, and the links on the card go to the pack's public page. Same form as the voice and work embeds below |

```bash
curl {{PUBLIC_BASE}}/pack/<packId>             # the page
curl {{PUBLIC_BASE}}/embed/pack/<packId>       # the player; <iframe src="{{PUBLIC_BASE}}/embed/pack/<packId>" width="100%" height="84" style="border:0"></iframe>
```

## Personal (`/api/v2/me/*`, auth)

`/`, `/profile`, `/items/{col}[/{id}]` (GET/PUT/DELETE), `/reactions` (GET/POST),
`notifications`, `/notifications/read`, `threads`, `threads/{peer}`, `usage`.

Legacy personal API (`/api/v1/me/*`, `/api/v1/community/{interactions,notifications}/*`,
`/api/v1/telemetry`, `/api/v1/status`, `/ops`) is served by `me-api.js` and kept for compatibility.

## MCP tools — `POST /mcp` (Streamable HTTP, JSON-RPC 2.0)

`search_voices` · `get_voice` · `list_languages` · `list_community_works` ·
`prepare_speech_request` · `synthesize_speech`.

## Embeds & agent doc

- `GET /embed/{voice|work}/{id}` — mini player (light/dark, links back to the app). A pack's player is `GET /embed/pack/{packId}` (see "Public page and embed of a pack" above).
- `GET /skill.md` — the base part's `SKILL.md` followed by `voice-studio.md` (the product guide), as one markdown document.
