# Voice Studio 的产品契约（Cohub 适配器）

**产品契约**是 Voice Studio 在 Cohub 上对外承诺的内容。机器可读的正本是同目录上一级的两个 JSON，app（`vs3/src/lib/contract.ts`，Vite 别名 `@base-part`）和服务端（`api-server/vs3-api.js`，启动时读）读的是同一份，所以改一处，两边一起变。本文件说明每个字段是什么，以及 JSON 里写不下的行为。字段的具体取值只看 JSON，这里不抄。

通用的词表（设计词表、场景词表、台本标记、能力词表）不属于产品契约，在基础部分的 `vocab/` 里。

## `../capability-map.json`：所需能力到模型的对照表

`capabilities` 的键是能力词表（`vocab/capabilities.json`）里的所需能力，值说明它在 Cohub 上怎么提供：

| 字段 | 含义 |
|---|---|
| `model` | Cohub 模型目录里的模型 id |
| `service` | 不按模型调用的 Cohub 服务，例如云端转写 |
| `url` | `service` 的地址（云端转写网关的 WebSocket 地址） |
| `unavailable` | Cohub 提供不了，写明原因；Cohub 的 agent 环境里这项能力报不可用 |
| `hostProvides` | 哪些运行环境自己能提供，例如 app 的本机声纹和本机分离 |
| `maxTextChars` | 一次请求最多接受多少个字符的文字，量过的才写（现在只有 `voice-design` 一项：试听文本）。数法和服务商一致，按 UTF-16 的单位数（一个表情符号算两个）。app 的设计页读它：按真正发出去的文字数，显示「n/上限」，超了不让生成（`vs3/src/lib/contract.ts` 的 `maxTextCharsFor`） |
| `languages` | `service` 转得对的语言（BCP 47 的主语言，小写），量过的才写（现在只有 `automatic-speech-recognition` 一项：云端转写）。调用方带了表外的语言，适配器在调用之前就报错，规则见 `vocab/capability-signatures.md` 的转写一节；app 把表外的语言交给本机的 Whisper（`vs3/src/lib/voicepack/capabilities.ts` 的 `recognitionRouted`）。没写就是不限制 |
| `note` | 用法上要注意的地方 |

app 和服务端的默认模型都从这里取：app 用 `modelFor(能力名)`，服务端在启动时算出 `modelDefaults`。表里缺某项需要的模型，服务端启动时就失败并点名缺的所需能力。

## `../product-contract.json`

| 字段 | 含义 |
|---|---|
| `publicBase`、`appUrl` | 服务的公开地址和 app 的地址 |
| `previewCard` | 分享文件里预览卡片（`index.html`）上的产品名和两个入口：`productName` 是「在 X 里打开」里的 X；`openQuery`（导入入口，进「我的声音」页）、`makeQuery`（「做一个你自己的」，带 `pack=<包 ID>`）是查询串，拼在 `appUrl` 后面就是入口的地址，`{id}` 换成包 ID。通用层的卡片生成程序（`protocol/lib/preview-card.mjs`）不写任何产品的名字和地址，只收调用方给的值；怎么给见下面「JSON 里写不下的行为」里的「预览卡片的值怎么给」 |
| `scopes` | 使用者授权：`ai` 是请求的授权范围，`targetKind` 是授权对象（使用者自己挑 Space），`redLines` 是计费红线 |
| `models` | 语音模型的目录：名称、界面上的短名、用途、最多几段参考（`maxRefs`）、文字最少几个字符（`minChars`）、是不是设计模型（`design`） |
| `aliases` | 别名到正式名，服务端按它换名 |
| `aliasPrefixes` | 名字以这些前缀开头的，也换成对应的正式名 |
| `openaiTts` | OpenAI 兼容接口：列出的模型、最长输入、可选格式、语速范围 |
| `synthesis` | 合成参数：分句上限、并发范围、停顿间隔、各语言的语速（用来估时长） |
| `sceneUseCases` | 场景到用途词的对照表：键是场景词表（`vocab/scenes.json`）里的场景 id，值是发现页「用途」那排按钮的词（音色库自己的音色用的就是这些词）。社区音色包的配音指引里写的是场景，服务端给它建索引时查这张表，按用途就能筛到包；对不上的场景不在表里，也就不出现在任何一个用途下，按场景 id 和场景的中文名照样搜得到 |
| `appMethods`、`mcpTools` | app 注册的方法，MCP 提供的工具 |
| `itemCollections` | 个人数据的集合名，服务端按它校验 |

## JSON 里写不下的行为

- **app 里选模型**（`vs3/src/lib/tts.ts` 的 `resolveModel`）：有设计描述而没有参考地址，用设计模型；参考地址多于一个，用克隆模型做融合；其余用请求里指定的（要在 `models` 里），没指定就用默认语音模型。整段文字解析一次，逐段再解析一次。
- **服务端换名**（`vs3-api.js` 的 `synthesize`）：先按 `aliases` 精确匹配（不分大小写），再按 `aliasPrefixes` 的前缀匹配；换完不在 `models` 里的返回 400；文字短于所选模型的 `minChars` 也返回 400。服务端没有 `resolveModel`：它只换名和校验，带一个参考地址。
- **授权失败的恢复**：生成请求遇到 403，先更新令牌，再让使用者重新挑 Space（`lib/cohub.ts` 的 `withAI`）。
- **预览卡片的值怎么给**：app 导出音色包时，`vs3/src/lib/voicepack/card.ts` 把 `previewCard` 和 `appUrl` 接成产品名和两个链接，交给 `buildShareFile` 的 `card` 选项。命令行用 Cohub 适配器做包时，适配器（`adapters/cohub/adapter.mjs`）给的 `previewCard` 就是同样接出来的值：`node cli.mjs make-pack … --cohub --share-file <分享文件>`，使用者不用自己给。单独用核心层的 `pack` 打包不认识适配器，要在命令行上给：`node cli.mjs pack <目录> --product-name "<productName>" --open-link "<appUrl><openQuery>" --make-link "<appUrl><makeQuery>"`（尖括号是上面表里对应字段的值，原样接起来；`{id}` 留着，打包时换成包 ID）。导入入口不带包 ID：导入是「我的声音」页上的「导入」按钮（选文件），页面收不了包 ID，所以这个链接只把人送到那一页。
