# Voice Studio（Cohub 适配器的产品说明）

Voice Studio 是 Cohub 上的声音创作平台：**创作 Studio / 社区 Community / 开发者 Developers**。这份说明给两类读者：调用它的 HTTP、OpenAI 兼容和 MCP 接口的 agent，和在 app 里操作它的 agent。`GET /skill.md` 把基础部分的 `SKILL.md` 和本文件拼成一个文档返回，开发者页显示的也是这一份。

- App：`{{APP_URL}}`
- API 地址：`{{PUBLIC_BASE}}`（接口说明 `GET /api/v2/openapi.json`，MCP `POST /mcp`）
- 源码：`vs3/`（Vite + React + TS）、`api-server/`（Node，不依赖第三方库）
- 上游：`debpalash/VoiceStudio`（AGPL-3.0），只借用它的设计系统和纯逻辑

## 费用和授权

**费用归使用者自己。** 生成、大语言模型和转写都跑在使用者自己的 Space 上，由使用者授权：`auth.authorize({ target: { kind: 'pick-space' } })`，授权范围 `generation.create`、`taskrun.view`、`session.prompt.readonly`。app 不持有任何 app 级授权，不花站长的额度。服务端的 OpenAI 兼容和 MCP 调用用**调用者的令牌**和调用者的 Space，不保存令牌。

## 模型

所需能力在 Cohub 上对到哪个模型，以 `capability-map.json` 为准；下面是给调用者看的摘要。

| 用途 | 模型 | 约束 |
|---|---|---|
| 默认语音；克隆；2–16 段带权重的融合 | `higgs-tts`（界面上叫 **Higgs TTS**） | 最多 16 段参考，文字至少 1 个字符 |
| 声音设计；单段参考的克隆 | `qwen-audio-3.0-tts-plus`（界面上叫 **Qwen Audio**） | 只接受 1 段参考，文字至少 15 个字符；描述用 `meta.voice_prompt` 传 |
| 头像、有声书封面 | `qwen-image-2.1` | 费用归使用者 |
| 润色、翻译、写描述、分配角色、写设计描述 | `qwen3.8-flash`（默认） | 费用归使用者 |

- **别名**（服务端会换成正式名）：`tts-1`、`tts-1-hd`、`gpt-4o-mini-tts`、`higgs` 换成 `higgs-tts`；`qwen`、`qwen-audio`，以及任何以 `qwen` 开头的名字，换成 `qwen-audio-3.0-tts-plus`。
- **app 里怎么选模型**：有设计描述而没有参考地址，用设计模型；参考地址多于一个，用克隆模型做融合；其余用请求里指定的，没指定就用默认语音模型。
- **模型的实时参数不要凭记忆写**：用 `cohub models show <模型 id>` 查。

## 页面和公开地址

app 里的页面（在 app 里用 `?p=<路由>` 打开，例如 `{{APP_URL}}?p=%2Fstudio%2Fspeak`）：

| 路由 | 流程 | 说明 |
|---|---|---|
| `/studio/speak` | 快速合成 | 文字、声音（可多个）、语速、水印 |
| `/studio/clone` | 声音克隆 | 参考音频、裁剪、清理、转写、试听、保存 |
| `/studio/design` | 声音设计 | 属性 → `voice_prompt` |
| `/studio/voices` | 我的声音 | 导出、导入音色包（`.voicepack.zip`：参考集、留出录音、配音指引、读音词表、验证记录；导出的是完整包，导入会检查，参考音频传到用户自己的 Cohub 账户）；老的 `.vsvoice.json` 仍可导入；可以带到创作页重新做 |
| `/studio/voices/:id/pack` | 做包 | 用「我的声音」里的一个声音做音色包：写配音指引、读音词表和示例台词，量还原度，导出；也可以发到社区 |
| `/studio/make-your-own` | 做一个你自己的 | 从别人的音色包出发（地址参数 `pack=<包 ID>`，或选一个分享文件），做一个和它没有关联的新包：只把想要的属性交给做包，不交来源包的角色内容；花钱之前和来源包查重 |
| `/studio/stories` | 多角色故事 | 台本解析、分段、分配角色 |
| `/studio/audiobook` | 长篇有声书 | 每段的生成任务有缓存 |
| `/studio/dub` | 视频配音 | 转写 → 翻译 → 对齐时长 → 合成 → 混音 |
| `/studio/batch` | 批量生成 | CSV 或多行文字 |
| `/studio/transcribe` | 转写和听写 | Cohub 流式转写（语音活动检测）或本机 Whisper；SRT、VTT |
| `/studio/tools` | 音频工具 | 分离、说话人分离、转换、对比、对齐、语气方向、水印、响度、探测、格式 |
| `/studio/projects` | 项目 | 草稿和渲染管理 |
| `/studio/history` | 生成记录 | 每次生成的结果 |
| `/studio` | 总览 | 入口 |

不在 app 里、由服务端直接给的公开地址（音色包的公开页 `/pack/{包 ID}` 和嵌入页 `/embed/pack/{包 ID}`）写在下面的「接口」里。

app 注册了几个可被 Cohub 宿主或 agent 调用的方法：`app.navigate`、`voice.search`、`studio.compose`、`player.play`、`community.openVoice`。

## 接口

完整清单见同目录的 `http-api.md`，下面是常用的。

- **免费**：`GET /api/v1/voices`（约 4.9 万个）、`/voices/{id}`、`/tags`、`/languages`、`/stats`、`/top`；`POST /api/v1/hit`。
- **OpenAI 兼容**：`POST /v1/audio/speech`（带调用者的令牌）、`GET /v1/models`。JSON 版：`POST /api/v2/tts`。
- **MCP**：`POST /mcp`，工具有 `search_voices`、`get_voice`、`list_languages`、`list_community_works`、`prepare_speech_request`、`synthesize_speech`。
- **社区**：`/api/v2/community/{voices,works,presets,packs,comments,counts,users,use,reports,moderate}`。音色包的发布、下载和错误码见 `http-api.md` 的「Voice packs」。
- **音色包的公开页和嵌入页**（不用登录）：`GET {{PUBLIC_BASE}}/pack/{包 ID}` 是公开页（服务端自己写的 HTML：试听、下载分享文件、嵌入代码、「做一个你自己的」按钮；带预览标签，社交平台抓链接预览不跑脚本），图片是 `/pack/{包 ID}/image.png`；`GET {{PUBLIC_BASE}}/embed/pack/{包 ID}` 是给 `<iframe>` 用的迷你播放器。作者撤下或被隐藏的包，这些地址都回 404。
- **个人数据**：`/api/v2/me/*`。**元数据**：`/api/v2/openapi.json`。**嵌入**：`/embed/{voice|work}/{id}`（音色包的见上一条）。
- **本文档**：`GET /skill.md`。

## 代码地图

每个流程的代码在哪。基础部分的词表和适配器数据（`vocab/`、`adapters/cohub/`）由 `vs3/src/lib/contract.ts` 通过 Vite 别名 `@base-part` 读进 app，服务端在启动时读。

```
vs3/src/lib/contract.ts     读基础部分的词表、对照表和产品契约；默认模型从这里取（modelFor / MODEL_FOR）
vs3/src/lib/tts.ts          resolveModel + synthesize（合成的枢纽）
vs3/src/lib/jobs.ts         后台合成任务，复用已有的生成任务（不重复付费）
vs3/src/lib/cohub.ts        身份、ensureAI / withAI（使用者授权）、生成、LLM、转写、上传
vs3/src/lib/llm.ts          润色、翻译、对齐时长、写描述、分配角色、设计
vs3/src/lib/text.ts         分句、台本标记、字幕、场景、读音词表
vs3/src/lib/asr.ts          云端转写（语音活动检测分段）和本机 Whisper
vs3/src/components/voice.tsx  声音的选择和融合、选择器、列表行
vs3/src/features/studio/*   每个流程一个文件（见上面的页面表）
api-server/vs3-api.js       社区、个人集合、媒体、OpenAI 兼容和 JSON 合成、MCP、OpenAPI、/skill.md
api-server/vs3-pack-*.js    社区音色包：存储和事务、公开页和嵌入卡片、配图、统计、性别和标签（vs3-api.js 把路由接上）
api-server/me-api.js        个人数据接口和可观测性
```

## 怎么调用

```bash
# 1) 搜声音（免费）
curl "{{PUBLIC_BASE}}/api/v1/voices?q=narrator&lang=English&pageSize=5"

# 2) 生成（费用归调用者，带你的 Cohub 令牌）
curl -X POST {{PUBLIC_BASE}}/v1/audio/speech \
  -H "Authorization: Bearer $COHUB_TOKEN" -H "Content-Type: application/json" \
  -d '{"model":"higgs-tts","voice":"<voice id>","input":"Hello"}' -o out.mp3

# 按一段描述设计声音（试听文字至少 15 个字符）
cohub generate "至少十五个字的试听文本内容。" --model qwen-audio-3.0-tts-plus \
  --meta '{"voice_prompt":"温柔沉静的年轻女声"}'

# 克隆；融合时传 2–16 段带权重的参考
cohub generate "Hello" --model higgs-tts --audio <ref-a.mp3> --audio <ref-b.mp3>
```

生成永远用调用者自己的 Cohub 账户。
