// SPDX-License-Identifier: Apache-2.0
//
// Cohub 云端转写的网关客户端：把一段 16 kHz、单声道、16 位的 PCM 经网关的 WebSocket 送去转写，收回文字。
// 由 env.mjs 的 automatic-speech-recognition 用；这个文件只管协议和失败怎么分类，令牌从哪来、失败怎么报成 VoicePackError 在 env.mjs。
//
// 协议（2026-10-15 对真网关的五次真音频探针和一次假令牌探针看到的，次数和每次的输出记在票 14；app 的 vs3/src/lib/cohub.ts 和 cohub-cli 带的 @neta-art/cohub 的
// voice-input 是同一个协议，这里照实测和那份公开的协议自己写，没有拿 app 的代码）：
//
//   客户端                         网关
//   （连上）                       system.ready  { connectionId }                  忽略
//   auth { token }                 system.auth.ok  { user }
//                                  令牌不对：asr.error { code: 'UNAUTHORIZED', message }，连接不断开（客户端自己关）
//   asr.start                      asr.started
//   asr.audio { audio } ×N         asr.partial { text, fullText }                  边送边来，忽略
//   asr.stop                       asr.final { text, fullText } ×M                 每一句一条；fullText 是到这一句为止接起来的全文：
//                                                                                  英文第二句起 text 开头带一个空格，中文不带，所以接的时候不加分隔
//                                  asr.done
//
//   audio 是 base64 的 PCM（16 kHz、单声道、16 位小端），每帧 200 毫秒，帧间停 17 毫秒左右（比实时快十来倍，网关吃得下）。
//   网关的 asr.final 没有时间戳：只有文字，不知道每句落在音频的哪里。
//   出错：asr.error、system.error，payload 是 { code?, message }；令牌被拒是 code 为 UNAUTHORIZED，或者 system.auth.ok 以外的 system.auth* 消息。
//   不认识的消息类型一律忽略（网关加新消息不该让这里坏掉）。
//
// 失败（plain Error，name 是 AsrGatewayError）带这几个字段，env.mjs 照它们报成 VoicePackError：
//   stage        在哪一步：connect（连接）、auth（等令牌确认）、start（等开始）、audio（送音频）、finish（等结果）
//   transient    true 表示服务暂时出错（连不上、连接出错或断开、哪一步等不到回应），稍后重来也许就成；false 是网关明确报的错
//   status       令牌被拒时是 401，别的没有；env.mjs 把它和 HTTP 401 一样处理（拦住这个环境后面的调用）
//   gatewayCode  网关在 payload.code 里给的
// 网关回的话里如果带着令牌，进报错之前先替换掉。
//
// WebSocket 用调用方给的（浏览器、Bun、Node 22 以上都自带一个）：形状只用到 onopen、onmessage、onerror、onclose、send、close。
//
// 模块约定见 protocol/README.md：只用平台自带的 API，浏览器和 Node 都能跑。
import { toBase64 } from '../../protocol/lib/bytes.mjs';

const RATE = 16000;
const BYTES_PER_SAMPLE = 2;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function failure(message, { stage, transient, status, gatewayCode, cause } = {}) {
  const error = new Error(message, cause === undefined ? undefined : { cause });
  error.name = 'AsrGatewayError';
  error.stage = stage;
  error.transient = transient === true;
  if (status !== undefined) error.status = status;
  if (gatewayCode !== undefined) error.gatewayCode = gatewayCode;
  return error;
}

/**
 * 从一段 WAV 里取出送给网关的 PCM：只收 16 kHz、单声道、16 位的 PCM WAV（网关只吃这个）。
 * @param {Uint8Array} bytes
 * @returns {{ pcm: Uint8Array } | { problem: string, found: string }} 不合格时给出原因（机器可读）和收到的是什么（给人看）
 */
export function pcmOfRecognitionWav(bytes) {
  const ascii = (at) => String.fromCharCode(bytes[at], bytes[at + 1], bytes[at + 2], bytes[at + 3]);
  if (bytes.length < 12 || ascii(0) !== 'RIFF' || ascii(8) !== 'WAVE') return { problem: 'not_wav', found: '不是 WAV（开头没有 RIFF/WAVE）' };
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let format = null;
  let at = 12;
  while (at + 8 <= bytes.length) {
    const id = ascii(at);
    const declared = view.getUint32(at + 4, true);
    const body = at + 8;
    if (id === 'fmt ' && body + 16 <= bytes.length) {
      format = { tag: view.getUint16(body, true), channels: view.getUint16(body + 2, true), rate: view.getUint32(body + 4, true), bits: view.getUint16(body + 14, true) };
    } else if (id === 'data') {
      if (format === null) return { problem: 'not_wav', found: 'data 块之前没有 fmt 块' };
      const description = `${format.tag === 1 ? 'PCM' : `编码 ${format.tag}`}、${format.bits} 位、${format.rate} Hz、${format.channels} 声道`;
      if (format.tag !== 1 || format.bits !== 16 || format.channels !== 1 || format.rate !== RATE) return { problem: 'format', found: description };
      const size = Math.min(declared, bytes.length - body) & ~1; // 声明的长度超出文件（流式输出写 0xFFFFFFFF）就按实际剩下的算；末尾不够一个采样的零头丢掉
      if (size === 0) return { problem: 'empty', found: 'data 块是空的' };
      return { pcm: bytes.subarray(body, body + size) };
    }
    at = body + declared + (declared & 1);
  }
  return { problem: 'not_wav', found: format === null ? '没有 fmt 块' : '没有 data 块' };
}

/**
 * 转写一段 PCM。
 * @param {object} options
 * @param {function} options.WebSocket WebSocket 的构造函数
 * @param {string} options.url 网关地址（wss://…）
 * @param {string} options.token 令牌，只放进 auth 消息
 * @param {Uint8Array} options.pcm 16 kHz、单声道、16 位小端的 PCM（不含 WAV 头）
 * @param {number} [options.frameMs] 每帧多少毫秒，默认 200
 * @param {number} [options.frameGapMs] 帧间停多久，默认 17 毫秒
 * @param {number} [options.connectTimeoutMs] 连接、等令牌确认、等开始，每一步最多等多久，默认 15 秒
 * @param {number} [options.idleTimeoutMs] 发完以后，网关多久没有任何回应就算超时，默认 30 秒（每来一条消息重新计）
 * @param {function} [options.onStage] 进到新的一步时调用，参数是步骤名（env.mjs 用它在失败时报告卡在哪一步）
 * @returns {Promise<{ text: string }>} 全文，首尾空白去掉；一句也没有识别出来是空串
 * @throws {Error} AsrGatewayError，字段见文件头
 */
export async function recognize({ WebSocket: Socket, url, token, pcm, frameMs = 200, frameGapMs = 17, connectTimeoutMs = 15_000, idleTimeoutMs = 30_000, onStage = () => {} }) {
  const frameBytes = Math.max(BYTES_PER_SAMPLE, Math.round((RATE * BYTES_PER_SAMPLE * frameMs) / 1000) & ~1);
  const scrub = (text) => String(text).split(token).join('[token]');

  const state = { stage: 'connect', open: false, authed: false, started: false, done: false, failure: null, finals: [] };
  const watchers = new Set();
  const notify = () => {
    for (const watch of [...watchers]) watch();
  };
  const fail = (error) => {
    if (state.failure === null && !state.done) {
      state.failure = error;
      notify();
    }
  };
  const enter = (stage) => {
    state.stage = stage;
    onStage(stage);
  };

  const handle = (data) => {
    let message;
    try {
      message = JSON.parse(typeof data === 'string' ? data : String(data));
    } catch {
      return; // 不是 JSON 的忽略
    }
    const type = typeof message?.type === 'string' ? message.type : '';
    const payload = message?.payload !== null && typeof message?.payload === 'object' ? message.payload : {};
    const gatewayCode = typeof payload.code === 'string' ? payload.code : undefined;
    const said = scrub(typeof payload.message === 'string' ? payload.message : type);
    if (type === 'system.auth.ok') state.authed = true;
    else if (type === 'asr.started') state.started = true;
    else if (type === 'asr.final') state.finals.push({ text: typeof payload.text === 'string' ? payload.text : '', fullText: typeof payload.fullText === 'string' ? payload.fullText : null });
    else if (type === 'asr.done') state.done = true;
    else if (gatewayCode === 'UNAUTHORIZED' || type.startsWith('system.auth')) {
      fail(failure(`转写网关拒绝了令牌（${type}${gatewayCode === undefined ? '' : ` ${gatewayCode}`}）：${said}`, { stage: state.stage, transient: false, status: 401, gatewayCode }));
    } else if (type === 'asr.error' || type === 'system.error') {
      fail(failure(`转写网关报错（${type}${gatewayCode === undefined ? '' : ` ${gatewayCode}`}）：${said}`, { stage: state.stage, transient: false, gatewayCode }));
    }
    notify();
  };

  /** 等到 condition 成立；网关出错或断开就立刻失败；timeoutMs 内没有进展就超时（idle 为 true 时，每来一条消息重新计）。 */
  const until = (condition, { timeoutMs, idle = false, waiting }) =>
    new Promise((resolve, reject) => {
      let timer = null;
      const settle = (done, value) => {
        clearTimeout(timer);
        watchers.delete(check);
        done(value);
      };
      const arm = () => {
        clearTimeout(timer);
        timer = setTimeout(() => settle(reject, failure(`${waiting}：${Math.round(timeoutMs / 1000)} 秒没有回应`, { stage: state.stage, transient: true })), timeoutMs);
      };
      function check() {
        if (state.failure !== null) settle(reject, state.failure);
        else if (condition()) settle(resolve);
        else if (idle) arm();
      }
      watchers.add(check);
      arm();
      check();
    });

  let socket;
  try {
    socket = new Socket(url);
  } catch (cause) {
    throw failure(`建不起转写网关的连接：${cause?.message ?? cause}`, { stage: 'connect', transient: false, cause });
  }
  const send = (message) => {
    try {
      socket.send(JSON.stringify(message));
    } catch (cause) {
      throw failure(`往转写网关发消息失败（${message.type}）：${cause?.message ?? cause}`, { stage: state.stage, transient: true, cause });
    }
  };
  socket.onopen = () => {
    state.open = true;
    notify();
  };
  socket.onerror = () => fail(failure('连接转写网关出错', { stage: state.stage, transient: true }));
  socket.onclose = (event) => fail(failure(`转写网关断开了连接（${event?.code ?? '?'}），没有等到结果`, { stage: state.stage, transient: true }));
  socket.onmessage = (event) => handle(event?.data);

  try {
    await until(() => state.open, { timeoutMs: connectTimeoutMs, waiting: '连接转写网关' });
    enter('auth');
    send({ type: 'auth', payload: { token } });
    await until(() => state.authed, { timeoutMs: connectTimeoutMs, waiting: '等转写网关确认令牌' });
    enter('start');
    send({ type: 'asr.start' });
    await until(() => state.started, { timeoutMs: connectTimeoutMs, waiting: '等转写网关开始' });
    enter('audio');
    for (let at = 0; at < pcm.length; at += frameBytes) {
      if (state.failure !== null) throw state.failure;
      send({ type: 'asr.audio', payload: { audio: toBase64(pcm.subarray(at, at + frameBytes)) } });
      await sleep(frameGapMs); // 帧间停一下；设成 0 也让出一次事件循环，网关断开、出错的消息才有机会在送的中途被看到
    }
    if (state.failure !== null) throw state.failure;
    enter('finish');
    send({ type: 'asr.stop' });
    await until(() => state.done, { timeoutMs: idleTimeoutMs, idle: true, waiting: '等转写网关出结果' });
    const last = state.finals.at(-1);
    const text = last?.fullText ?? state.finals.map((final) => final.text).join('');
    return { text: text.trim() };
  } finally {
    try {
      socket.close();
    } catch {
      // 已经关了
    }
  }
}
