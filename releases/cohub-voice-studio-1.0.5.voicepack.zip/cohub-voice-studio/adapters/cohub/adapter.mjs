// SPDX-License-Identifier: Apache-2.0
//
// Cohub 适配器的工厂：命令行上的 --adapter cohub（简写 --cohub，Space 用 --space，见 adapter.json）加载的就是它。
// 工厂的签名、返回的形状、出错的约定，写在 ../README.md；这里只写 Cohub 自己的做法。
//
// 做的事：按 PATH 找到 cohub-cli 自带的客户端（cli/client.mjs），用它组装 Cohub 的所需能力（env.mjs 的 createCohubEnvironment），交给命令。
//   Space     options.space（--space），没有就取环境变量 COHUB_SPACE_ID，都没有抛 cohub_space_missing（在碰 Cohub 之前）
//   凭据      这里不读任何凭据：Cohub 的登录态或执行令牌是 cohub-cli 自己带的。转写（automatic-speech-recognition）走网关的 WebSocket，要自己带令牌：
//             给 env.mjs 的是 cli/client.mjs 的 cohubTokenSource()，一个每次转写时向 cohub-cli 现取令牌的函数（沙箱里是执行令牌，本机是登录态里的访问令牌，
//             细节见 README.md「转写的令牌」）；这里不碰令牌的值
//   网络和运行时  命令已有的 fetch 和 runtimes（转写要 ffmpeg 把别的格式转成 16 kHz 单声道）原样交给 env.mjs
//   billing   生成和调用记在使用者自己的 Cohub 账户上，命令据此在合成开始之前说明要调几次
//   limits    maxChars 取自产品契约的 synthesis.chunkMax（product-contract.json），不在这里另写一份
//   previewCard  分享文件的预览卡片上的产品名和两个入口：取自产品契约的 previewCard 和 appUrl（查询串接在 appUrl 后面，拼法见 reference/product-contract.md），
//             不在这里另写一份。make-pack 的 --share-file 把它交给卡片生成程序，使用者不用自己给
//
// 抛出的错误：cohub_space_missing；cohub_cli_not_found、cohub_cli_invalid 来自 cli/client.mjs；别的 cohub_* 来自 env.mjs 组装出来的能力。
// 这个文件在适配器的主人一侧运行：可以用 Node 专有的东西（process.env），规则见 ../README.md「Node 专有的东西放哪」。
import product from './product-contract.json' with { type: 'json' };
import { VoicePackError } from '../../protocol/lib/errors.mjs';
import { createCohubEnvironment } from './env.mjs';
import { cohubTokenSource, loadCohubClient } from './cli/client.mjs';

export default async function createCohubAdapter({ env, options }) {
  const spaceId = (typeof options.space === 'string' && options.space !== '' ? options.space : undefined) ?? process.env.COHUB_SPACE_ID ?? '';
  if (spaceId === '') {
    throw new VoicePackError('cohub_space_missing', '用 Cohub 要有一个 Space：用 --space <id> 给，或者设上环境变量 COHUB_SPACE_ID。生成和调用都记在使用者自己的账户上', { details: {} });
  }
  const client = await loadCohubClient();
  const cohub = createCohubEnvironment({ client, spaceId, fetch: env.fetch, accessToken: cohubTokenSource(), runtimes: env.runtimes });
  return {
    capabilities: cohub.capabilities,
    billing: `在 Space ${spaceId} 上调用 Cohub，费用记在使用者自己的账户上`,
    limits: { maxChars: product.synthesis.chunkMax },
    previewCard: {
      productName: product.previewCard.productName,
      links: { open: `${product.appUrl}${product.previewCard.openQuery}`, make: `${product.appUrl}${product.previewCard.makeQuery}` },
    },
  };
}
