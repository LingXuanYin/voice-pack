// SPDX-License-Identifier: Apache-2.0
//
// 在 agent 环境里找到 cohub-cli 自带的 Cohub 客户端。Node 专有（读 PATH、读文件、动态 import），所以放在适配器的 cli/ 目录里（Node 专有的东西只准出现在
// 命令行层：cli.mjs、名为 cli/ 的目录，和官方适配器的入口 adapter.mjs，规则见 adapters/README.md）；可移植的部分（env.mjs，按所需能力的形状组装环境）不碰它，客户端由调用方给。
//
// 做法同 `command -v cohub`：按 PATH 的先后找名叫 cohub 的可执行文件，认出它属于哪个 @neta-art/cohub-cli 包，
// 再加载包里的 dist/client.js，调它的 createClient()。Cohub 的 agent 环境里 cohub 是预装的，登录态或执行令牌也是它自己带的，
// 所以这里不读任何凭据，也不碰环境变量里的令牌；拿到的客户端怎么鉴权是 cohub-cli 的事。
//
// 两种安装布局都认：
//   - npm 全局安装的垫片：PATH 里的目录里有 cohub（Windows 上还有 cohub.cmd、cohub.ps1），同一目录下 node_modules/@neta-art/cohub-cli 就是包；
//   - 可执行文件解开符号链接以后落在包目录里（Linux 上 cohub 是指向包内 bin 文件的链接）：往上找到 package.json。
// 认的是包名，不是文件名：别的程序恰好也叫 cohub，旁边的包不是 @neta-art/cohub-cli，就不认。
//
// 抛出的错误（VoicePackError，details 里放什么在抛出处写明）：
//   cohub_cli_not_found  PATH 里找不到属于 @neta-art/cohub-cli 的 cohub。details.searched 是查过几个目录
//   cohub_cli_invalid    找到了包，但客户端用不了：没有 dist/client.js、加载失败、没导出 createClient、createClient() 抛了错。
//                        details.root 是包目录，details.file 是客户端文件；底层错误在 cause 里
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { VoicePackError } from '../../../protocol/lib/errors.mjs';

const PACKAGE_NAME = '@neta-art/cohub-cli';
const EXECUTABLES = ['cohub', 'cohub.cmd', 'cohub.exe', 'cohub.ps1'];

const isFile = (file) => {
  try {
    return fs.statSync(file).isFile();
  } catch {
    return false;
  }
};

const packageNameAt = (dir) => {
  try {
    return JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8')).name;
  } catch {
    return null;
  }
};

/** 从 file 所在的目录往上找名叫 @neta-art/cohub-cli 的包目录；找不到是 null。 */
function packageAbove(file) {
  let dir = path.dirname(file);
  for (;;) {
    if (packageNameAt(dir) === PACKAGE_NAME) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) return null;
    dir = parent;
  }
}

/**
 * 按 PATH 找 cohub-cli 的包目录。
 * @param {{ searchPath?: string }} [options] searchPath：PATH 的内容，省略用本进程的 PATH
 * @returns {{ root: string, executable: string, searched: number } | null} root 是包目录，executable 是 PATH 里找到的那个 cohub 文件；找不到是 null
 */
export function findCohubPackage({ searchPath = process.env.PATH ?? process.env.Path ?? '' } = {}) {
  const dirs = searchPath
    .split(path.delimiter)
    .map((dir) => dir.trim().replace(/^"(.*)"$/, '$1'))
    .filter((dir) => dir !== '');
  for (const [index, dir] of dirs.entries()) {
    for (const name of EXECUTABLES) {
      const executable = path.join(dir, name);
      if (!isFile(executable)) continue;
      let real = executable;
      try {
        real = fs.realpathSync(executable);
      } catch {
        // 解不开链接就按原路径找
      }
      const inside = packageAbove(real);
      if (inside !== null) return { root: inside, executable, searched: index + 1 };
      const beside = path.join(dir, 'node_modules', ...PACKAGE_NAME.split('/'));
      if (packageNameAt(beside) === PACKAGE_NAME) return { root: beside, executable, searched: index + 1 };
    }
  }
  return null;
}

/**
 * 找到 cohub-cli，加载它的客户端，返回 createClient() 的结果（Cohub 客户端，形状见 env.mjs 的文件头）。
 * @param {{ searchPath?: string }} [options] 同 findCohubPackage
 * @returns {Promise<object>}
 * @throws {VoicePackError} cohub_cli_not_found、cohub_cli_invalid
 */
export async function loadCohubClient(options = {}) {
  const found = findCohubPackage(options);
  if (found === null) {
    throw new VoicePackError(
      'cohub_cli_not_found',
      `找不到 cohub 命令行工具：PATH 里没有 cohub，或者它不是 ${PACKAGE_NAME} 装出来的。Cohub 的 agent 环境里它是预装的；别处用 npm install -g ${PACKAGE_NAME} 装上，再用 cohub auth login 登录`,
      { details: { searched: (options.searchPath ?? process.env.PATH ?? process.env.Path ?? '').split(path.delimiter).filter((dir) => dir.trim() !== '').length } },
    );
  }
  const file = path.join(found.root, 'dist', 'client.js');
  const invalid = (reason, cause) => new VoicePackError('cohub_cli_invalid', `cohub-cli（${found.root}）的客户端用不了：${reason}`, { details: { root: found.root, file }, ...(cause === undefined ? {} : { cause }) });
  if (!isFile(file)) throw invalid('没有 dist/client.js');
  let loaded;
  try {
    loaded = await import(pathToFileURL(file).href);
  } catch (cause) {
    throw invalid(`加载失败：${cause?.message ?? cause}`, cause);
  }
  if (typeof loaded.createClient !== 'function') throw invalid('dist/client.js 没有导出 createClient');
  try {
    return loaded.createClient();
  } catch (cause) {
    throw invalid(`createClient() 抛了错：${cause?.message ?? cause}`, cause);
  }
}

/**
 * 令牌的来源：cohub-cli 自带的 resolveAccessToken()（dist/auth.js）。返回一个函数，每次调用取一次令牌，交给 env.mjs 的 accessToken 选项
 * （转写走网关的 WebSocket，要自己带令牌）：
 *   - Space 沙箱里 COHUB_EXECUTION_TOKEN 有值，就是它（独占，不回退登录态）；
 *   - 本机用 cohub auth login 登录过的用户，是登录态里的访问令牌（~/.config/cohub/auth.json），快到期（5 分钟内）时 cohub-cli 自己拿刷新令牌换新并写回。
 * 这个函数不自己读环境变量、不读文件，也不把令牌存下来：每次转写开始时现取，令牌的值只流进发给网关的 auth 消息。
 * 第一次调用才去找 cohub-cli 的包、加载 auth.js，所以不转写的命令不受影响。
 * 抛出的错误：cohub_cli_not_found、cohub_cli_invalid（同 loadCohubClient，details.file 是 auth.js）；没登录或登录态失效时 cohub-cli 抛的错
 * （AuthRequiredError）原样抛出，resolveAccessToken 返回空时抛一个说明「重新登录」的 Error，适配器把它们报成 cohub_token_unavailable。
 * @param {{ searchPath?: string }} [options] 同 findCohubPackage
 * @returns {() => Promise<string>}
 */
export function cohubTokenSource(options = {}) {
  let resolveAccessToken = null;
  return async () => {
    if (resolveAccessToken === null) {
      const found = findCohubPackage(options);
      if (found === null) {
        throw new VoicePackError(
          'cohub_cli_not_found',
          `找不到 cohub 命令行工具，拿不到转写要用的令牌：PATH 里没有 cohub，或者它不是 ${PACKAGE_NAME} 装出来的。Cohub 的 agent 环境里它是预装的；别处用 npm install -g ${PACKAGE_NAME} 装上，再用 cohub auth login 登录`,
          { details: { searched: (options.searchPath ?? process.env.PATH ?? process.env.Path ?? '').split(path.delimiter).filter((dir) => dir.trim() !== '').length } },
        );
      }
      const file = path.join(found.root, 'dist', 'auth.js');
      const invalid = (reason, cause) => new VoicePackError('cohub_cli_invalid', `cohub-cli（${found.root}）里取令牌的模块用不了：${reason}`, { details: { root: found.root, file }, ...(cause === undefined ? {} : { cause }) });
      if (!isFile(file)) throw invalid('没有 dist/auth.js');
      let loaded;
      try {
        loaded = await import(pathToFileURL(file).href);
      } catch (cause) {
        throw invalid(`加载失败：${cause?.message ?? cause}`, cause);
      }
      if (typeof loaded.resolveAccessToken !== 'function') throw invalid('dist/auth.js 没有导出 resolveAccessToken');
      resolveAccessToken = loaded.resolveAccessToken;
    }
    const token = await resolveAccessToken();
    if (typeof token !== 'string' || token.trim() === '') throw new Error('Cohub 的登录态已经失效（刷新令牌被拒）：运行 cohub auth login 重新登录');
    return token;
  };
}
