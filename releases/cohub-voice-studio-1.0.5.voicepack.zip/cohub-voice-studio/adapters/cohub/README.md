# Cohub 适配器

基础部分里唯一可以点名模型的适配器（`api-server/tests/voicepack/model-names.test.mjs` 按这条检查）。适配器是什么、工厂怎么写、出错怎么报，约定只写在 `../README.md`，这里只写 Cohub 自己的。它同时装着 Voice Studio 的产品契约和给人读的参考文档。

## 目录

```
adapters/cohub/
├── README.md                本文件
├── adapter.mjs              适配器的工厂：命令行上的 `--adapter cohub`（简写 `--cohub`）加载的就是它；Node 专有（读环境变量、按 PATH 找 cohub-cli），app 不加载它
├── adapter.json             命令行上的样子：`--cohub` 是简写，`--space <id>` 是它的参数（写法见 `../README.md`）
├── cli/client.mjs           Node 专有：按 PATH 找到 cohub-cli 自带的客户端，给转写取令牌的函数
├── capability-map.json      所需能力 -> Cohub 模型的对照表（app 和服务端的默认模型从这里取）
├── env.mjs                  按 protocol/README.md 的形状组装运行环境：text-to-speech、voice-cloning、audio-text-to-text、text-generation、automatic-speech-recognition（给了令牌才有）
├── asr-gateway.mjs          转写网关（WebSocket）的客户端：协议、分帧、怎么分辨「令牌被拒」「暂时出错」「网关报的错」，env.mjs 用
├── failure.mjs              Cohub 的失败和异常回答怎么分类：哪些算「服务暂时出错」（HTTP 状态、网络错误、任务失败时服务商回的状态），和听音频的回答是不是被服务商拦下了（provider_blocked），和服务商拒绝一次请求是不是因为文字超过了它的字数上限（textTooLong，上限本身写在 capability-map.json 的 maxTextChars）：一条规则，env.mjs 和调用方（app 配音时为失败的一句重新建任务、对用户说「文字太长」）共用
├── product-contract.json    Voice Studio 的产品契约：授权范围、计费红线、模型约束、别名、接口限制、合成参数
└── reference/               给人读的说明
    ├── voice-studio.md      产品说明：费用、模型、页面、接口、代码地图、怎么调用（GET /skill.md 会接在基础部分 SKILL.md 后面一起返回）
    ├── flows.md             app 里每条流程的细节（合成管线、克隆、设计、融合、后台任务、身份和上传）
    ├── http-api.md          HTTP、OpenAI 兼容、MCP、嵌入接口的清单
    └── product-contract.md  上面两个 JSON 的字段说明，以及 JSON 里写不下的行为
```

## 谁读它

- app：`vs3/src/lib/contract.ts` 通过 Vite 别名 `@base-part` 读 `vocab/`、`adapters/cohub/` 下的 JSON，构建时内联。改了这些数据要重新构建前端（`api-server/deploy.sh` 的分类里算前端）。
- 服务端：`api-server/vs3-api.js` 在启动时读，缺文件或表里缺模型就起不来；改完要重载。
- `env.mjs`（`createCohubEnvironment`）：浏览器和 Node 里都能跑，Cohub 客户端、Space、网络读取由调用方给，不读环境变量。在 agent 环境里，调用方是本目录的 `adapter.mjs`：`cli/client.mjs` 按 PATH 找到 cohub-cli 自带的客户端，`node cli.mjs fidelity <评测集> --cohub` 就是这么用的；app 里用 app 自己的客户端。它提供的能力、两件只有 Cohub 才有的做法（参考音频先上传再生成、音频按 base64 放进 image 块）、失败时的 code 和重试规则，都写在 `env.mjs` 的文件头，这里不重复。

## 命令行怎么用

`--cohub [--space <id>]` 就是 `--adapter cohub [--adapter-option space=<id>]`（统一的入口和合并规则只在 `cli/adapters.mjs` 写）。

- **Space**：`--space`（给 `space` 选项）优先，没有就取环境变量 `COHUB_SPACE_ID`，都没有抛 `cohub_space_missing`，在碰 Cohub 之前。
- **费用**：生成和调用记在使用者自己的 Cohub 账户上，适配器给的 `billing` 是「在 Space <id> 上调用 Cohub，费用记在使用者自己的账户上」，命令在花钱之前据此说明。
- **一次合成的字数上限**：适配器给的 `limits.maxChars` 取自产品契约的 `synthesis.chunkMax`（`product-contract.json`，数值只在那里写），`dub` 默认按它切句子。
- **分享文件的预览卡片**：适配器给的 `previewCard` 取自产品契约的 `previewCard` 和 `appUrl`（拼法见 `reference/product-contract.md`）。`make-pack` 加 `--share-file <分享文件>` 打分享文件时，卡片上就有「在 Voice Studio 里打开」和「做一个你自己的」两个入口，不用自己给链接。

## 提供什么、不提供什么

提供：`text-to-speech`、`voice-cloning`、`audio-text-to-text`、`text-generation`，和转写 `automatic-speech-recognition`（给了令牌才有，命令行上总是给了）。每一项对到哪个模型，看 `capability-map.json`；实现的细节（怎么传参考音频、怎么让模型听音频、失败怎么报、哪些重试）在 `env.mjs` 的文件头。

不提供：`style-instruction`、`voice-conversion`、`singing-voice-conversion`、`speaker-verification`、`audio-source-separation`、`voice-activity-detection`（Cohub 的模型目录里没有）。用到它们的功能报 `capability_missing`，其他功能照常；要用的话，再接一个提供它的适配器。

转写的几点特别之处：它是一个服务不是模型（走网关的 WebSocket，用使用者自己的令牌鉴权，见下一节）；只收 16 kHz、单声道、16 位的 WAV，别的格式用环境的 `ffmpeg` 运行时转，环境没有就抛 `runtime_missing`；返回里没有语言，也没有时间戳（下面「网关的几条实测」）。令牌被拒（网关回 `UNAUTHORIZED`）按 401 处理：抛 `cohub_unauthorized`，这个环境之后不再向 Cohub 发请求（凭据被拒的一般约定见 `../README.md`「出错的约定」）。

## 转写的令牌

转写（`automatic-speech-recognition`）不走生成接口，走网关的 WebSocket（`wss://gateway.cohub.live/asr/ws`，协议见 `asr-gateway.mjs` 文件头），要自己带令牌。`createCohubEnvironment` 不读环境变量，令牌由调用方传进来：`accessToken` 选项，给字符串，或者给一个每次转写时现取令牌的函数（令牌会过期、会刷新，所以命令行层给的是函数）；**不给就没有这项能力**，用到它的功能抛 `capability_missing`。令牌的值只出现在发给网关的 `auth` 消息里，不进任何报错、日志、`details`（测试里有专门的检查：网关把令牌回显在错误里，报错里也没有）。

令牌从哪来，由 cohub-cli 自己的 `resolveAccessToken()` 决定（`dist/auth.js`，读源码得出）。`cli/client.mjs` 里 `cohubTokenSource()` 把它包成上面说的函数，`adapter.mjs`（所有 `--cohub` 命令）已经接上，agent 和本机的用户不用自己拿：

| 在哪 | 令牌是什么 |
|---|---|
| Cohub Space 的沙箱（agent 会话、值守） | 环境变量 `COHUB_EXECUTION_TOKEN` 有值就用它，独占，不回退到登录态（2026-10-14 leader 在沙箱里用它调通过转写） |
| 本机用 `cohub auth login` 登录过的用户 | 登录态里的访问令牌，存在用户目录下的 `.config/cohub/auth.json`（Windows 上是 `C:/Users/<用户名>/.config/cohub/auth.json`）。访问令牌约 24 小时到期，到期前 5 分钟起 cohub-cli 用刷新令牌换新并写回，有跨进程的锁；换新这件事不用我们管 |
| 登录态失效（刷新令牌被拒） | cohub-cli 清掉登录态，`resolveAccessToken()` 返回空；`cohubTokenSource()` 抛一个叫你运行 `cohub auth login` 的错，适配器报 `cohub_token_unavailable` |
| app（浏览器） | app 自己的 `getToken()`，不在基础部分里 |

要手动取令牌的话（本机，例如写自己的脚本）：不要自己读 `auth.json`，调 cohub-cli 的 `resolveAccessToken()`（`import` 它包里的 `dist/auth.js`），这样刷新、加锁、沙箱的执行令牌都对。**不要手写 `Authorization` 头去试**：HTTP 请求里一次 401，cohub-cli 的客户端（`dist/client.js` 的 `onUnauthorized`）就会清掉本机的登录态，让整台机器的 `cohub` 退出登录。转写走的是我们自己的 WebSocket，网关拒绝令牌（`asr.error`，`code` 是 `UNAUTHORIZED`）不经过那个钩子，不会清登录态（读 `dist/client.js` 得出，没有拿真令牌的失败去试），但适配器仍然把它当 401：抛 `cohub_unauthorized`，这个环境之后不再向 Cohub 发请求，调用方应当停下来。

网关的几条实测（2026-10-15，本机，5 次真转写加 1 次假令牌，次数和每次的输出记在票 14）：只回文字，没有时间戳也没有语言；一次转写的连接要 1 秒多（连上、鉴权、开始）；`asr.final` 一句一条，`fullText` 是到这一句为止的全文（英文的第二句起，`text` 开头带一个空格；中文不带），适配器取最后一条的 `fullText`；连续讲 18 秒不停顿，网关只回了一条 `asr.final`，没有按长度截断；假令牌回 `asr.error`（`code: UNAUTHORIZED`），连接不会自己断。

## 改点什么

- **换模型、加别名、改限制**：改 `capability-map.json` 和 `product-contract.json`，app 和服务端跟着变，别在代码里写死。
- **加一个适配器**：在 `adapters/` 下新建 `<名字>/`，写法见 `../README.md`，不动基础部分的其他地方。
- **费用**：照旧走使用者自己的 Cohub 账户，见基础部分 `SKILL.md` 的红线。
- **给 LLM 传音频**：Cohub 的 LLM 接口会把 `audio` 内容块丢掉，要按 `capability-map.json` 里 `audio-text-to-text` 那条 note 说的传法。那是实测出来的用法，Cohub 的文档里没有，只在这一层里用。做法实现在 `env.mjs`。

## 在 Node 里用

```js
// 在基础部分的根目录里（路径相对它）；cli/client.mjs 是 Node 专有的，所以放在 cli/ 下
import { loadCohubClient } from './adapters/cohub/cli/client.mjs';
import { createCohubEnvironment } from './adapters/cohub/env.mjs';
const env = createCohubEnvironment({ client: await loadCohubClient(), spaceId: '<Space id>', fetch: globalThis.fetch.bind(globalThis) });
// env.capabilities['voice-cloning']({ text, ref_audio: { bytes, mimeType } }) -> { bytes, mimeType, model }
```

环境里没有 `speaker-verification`（Cohub 的模型目录里没有）：需要它的功能要自己往 `env.capabilities` 里补，或者传给 `createCohubEnvironment` 的 `capabilities`。命令行里等价的是 `node cli.mjs fidelity <评测集.json> --cohub --space <Space id>`。

## 改了 `env.mjs` 以后：冒烟检查

规格「不进常规测试」：对真模型的调用（包括让 gemini 收音的传法）只在改适配器时手工跑一次，用最小的量。

1. 备一份最小评测集：一段参考、一条留出录音（都是真的录音文件，留出录音带它说的话，不给 `generated`）。评测集的写法见 `cli/evaluation-set.mjs` 的文件头。
2. `node cli.mjs fidelity <评测集.json> --cohub --space <Space id>`：1 次合成（含上传参考）加 2 次盲听。
3. 看三件事：合成没有报错；盲听那一栏是「有效 1 条」，不是「全部作废」（作废说明收音校验没过，模型没听到音频，要查 image 块的传法有没有失效；如果作废清单里写的是 `provider_blocked`，那是服务商把这次回答拦下了，不是传法失效，换一段台词不是现成文章的录音再试）；说话人相似度是「量不了」（对的，Cohub 上没有 speaker-verification）。
4. `text-to-speech` 没有命令行入口，要验就用上面几行 Node 调一次。
5. 预算：最多 3 次合成、5 次 gemini 调用。**遇到 401 立刻停**：本机上一次 401 会清掉 Cohub 的登录态，别手写 Authorization 头去试。上游 5xx 隔几分钟再来，最多 3 次，还不行就如实记下。
6. 转写没有命令行入口的冒烟：用 `cohubTokenSource()` 和 `createCohubEnvironment({ client, spaceId, fetch, accessToken })` 对一段几秒的公开语料音频调一次 `automatic-speech-recognition`，看文字对得上。预算：几秒的音频，不重试；令牌被拒立刻停。
7. 2026-10-14 的实测（本机，cohub-cli 10.2.0）：合成一句约 4 秒（text-to-speech），克隆约 33 秒；上传一段 285 KB 的 mp3 约 2 秒；gemini 每次 15 到 90 秒，两段音频的转写都逐字对上；一次克隆在轮询中途遇到过一次连接超时（本机网络，不是 Cohub），所以有了「接着等同一个任务」的重试。
